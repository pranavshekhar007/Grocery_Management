<?php
	include("AdminFirstHomePage.php");
	include("AdminSecondHomePage.php");
	include("connection.php");
	echo "<div>&nbsp;</div><div>&nbsp;</div>";
	echo "<div class='container'>
			<div class='row'>
				<h1>View Rate Us - </h1>
			</div>";
	echo "<div>&nbsp;</div><div>&nbsp;</div>";
	echo "<table border=1 style='font-size:18px;' width=90%>
				<tr>
					<th class='text-center'>Email Id</th>
					<th class='text-center'>Star</th>
				</tr>";
	$sql="select * from rate_us";
	$res=mysqli_query($conn,$sql);
	if(isset($res))
	{
		while($data=mysqli_fetch_assoc($res))
		{
			$s=$data["Star"];
			$email=$data["Email_Id"];
			echo "<tr align='center'>
					<td>$email</td>
						<td>";
							for($i=1;$i<=$s;$i++)
							{
								echo "<img src='Images/star.png' width=50 height=50>";
							}
			echo"			</td>
					</tr>";
		}
	}
	echo "</table>";
	echo "</div>";
?>
<html>
	<head>
	</head>
	<head>
		<style>
			#view_rate{
				background:url("Images/1.jpg");
				background-size:cover;
			}
		</style>
	</head>
	<body id="view_rate">
	</body>
</html>