-- phpMyAdmin SQL Dump
-- version 2.9.2
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Jul 31, 2020 at 01:07 PM
-- Server version: 5.0.27
-- PHP Version: 5.2.1
-- 
-- Database: `mydb`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `add_sub_product`
-- 

CREATE TABLE `add_sub_product` (
  `Image` varchar(20) NOT NULL,
  `Product_Name` varchar(40) NOT NULL,
  `Product_Weight` varchar(10) NOT NULL,
  `Product_Price` varchar(10) NOT NULL,
  `Offer` varchar(10) NOT NULL,
  `Discount_Price` varchar(10) NOT NULL,
  `Product_Type` varchar(40) NOT NULL,
  PRIMARY KEY  (`Product_Name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `add_sub_product`
-- 

INSERT INTO `add_sub_product` (`Image`, `Product_Name`, `Product_Weight`, `Product_Price`, `Offer`, `Discount_Price`, `Product_Type`) VALUES 
('Candy.jpg', 'Alpenliebe Gold Candy', '195 gm', '50', '0', '50', 'Chocolate and Candies'),
('Cheese.jpg', 'Amul Cheese', '200 gm', '125', '9', '113.75', 'Butter and Cheese'),
('Cake.jpg', 'Amul Milk Cake', '150 gm', '95', '10', '85.5', 'Sweets'),
('Paneer.jpg', 'Amul Paneer', '200 gm', '97', '10', '87.3', 'Paneer and Curd'),
('Arhar.jpg', 'Arhar Dal', '1 Kg', '120', '17', '99.6', 'Pulses'),
('Aata.jpg', 'Atta', '10 KG', '490', '22', '382.2', 'Atta and Other Flour'),
('Baby_access1.jpg', 'Baby Eating Care', '1 Unit', '330', '15', '280.5', 'Baby Accessories'),
('Rice.jpg', 'Basmati Rice', '1 Kg', '60', '5', '57', 'Rice and Other Grains'),
('Chips .jpg', 'Bingo Cream and Onion Flavour Chips', '2x90 gm', '70', '20', '56', 'Chips and Crips'),
('Brinjal.jpg', 'Brinjal', '1 Unit', '45', '40', '27', 'Vegetables'),
('Bread.jpg', 'Brown Bread', '20 gm', '25', '0', '25', 'Bread and Eggs'),
('Cat_food.jpg', 'Cat Food', '500 gm', '500', '10', '450', 'Cat Supplies'),
('Chana.jpg', 'Chana Dal', '1 Kg', '90', '20', '72', 'Pulses'),
('Chilli.jpg', 'Chilli Powder', '100 gm', '58', '5', '55.1', 'Spices'),
('corri.webp', 'Coriander Powder', '200 gm', '57', '15', '48.45', 'Spices'),
('Crips .jpg', 'Cornitoes Nacho Crips', '3x19 gm', '90', '10', '81', 'Chips and Crips'),
('Choco.jpg', 'Diary Milk Chocolates', '150 gm', '160', '10', '144', 'Chocolate and Candies'),
('Conditioner.jpg', 'Dove Conditioner', '175 ml', '200', '8', '184', 'Hair Care'),
('Soap.jpg', 'Dove Cream Beauty Body Soap', '3x100 gm', '160', '12', '140.8', 'Skin Care'),
('Drink.jpg', 'Enerzal Energy Drink', '1 litre', '330', '12', '290.4', 'Health and Energy Drinks'),
('Besan.jpg', 'Fortune Besan', '500 gm', '64', '16', '53.76', 'Atta and Other Flour'),
('Wipes.jpg', 'Happy Baby Cheery Blossom Baby Wipes', '2x80 Units', '350', '50', '175', 'Diapers and Wipes'),
('Chutney.jpg', 'Happy Schezwan Chutney', '250 gm', '75', '8', '69', 'Pickles and Chutneys'),
('Facewash.jpg', 'Himalaya Purifying Neem Face Wash', '150 ml', '155', '7', '144.15', 'Skin Care'),
('Horlicks.jpg', 'Horlicks Protein + Vanilla Health Drink', '400 gm ', '535', '9', '486.85', 'Health and Energy Drinks'),
('Baby_shampoo.jpg', 'Johnson''s No More Tears Baby Shampoo', '475 ml', '360', '8', '331.2', 'Baby Skin and Hair Care'),
('Baby_wash.jpg', 'Johnson''s Top to Toe Baby Wash', '200 ml', '200', '20', '160', 'Baby Skin and Hair Care'),
('Soup.jpg', 'Knoor Cup Soup', '20 gm', '10', '0', '10', 'Sauces and Ketchups'),
('Tea.jpg', 'Lipton Darjeeling Tea', '250 gm', '460', '5', '437', 'Tea and Coffee'),
('Noodle.jpg', 'Maggie Special Masala Noodles', '2x70 gm', '30', '5', '28.5', 'Noodles and Suaces'),
('Mango.jpg', 'Mango', '1 Kg', '120', '19', '97.2', 'Fruits'),
('Lip_balm.jpg', 'Maybelline Baby Lips Color', '1 Unit', '99', '5', '94.05', 'Cosmetics'),
('Curd.jpg', 'Milky Fresh Curd', '2x1 Kg', '198', '8', '182.16', 'Paneer and Curd'),
('Water.jpg', 'Mineral Water Bottle', '2 l', '40', '20', '32', 'Water and Soda'),
('Coffee.jpg', 'Nescafe Classic Coffee', '100 gm', '290', '10', '261', 'Tea and Coffee'),
('Baby_food.jpg', 'Nestle Cereloc with Milk', '300g', '320', '41', '188.8', 'Baby Food'),
('Baby_food1.jpg', 'Nestle Lactogen 1 Infant Formula', '400 gm', '330', '9', '300.3', 'Baby Food'),
('Pampers.jpg', 'Pampers Premium Care Pants Diaper(L)', '44 unit', '1049', '23', '807.73', 'Diapers and Wipes'),
('Mix_fruit.jpg', 'Patanjali Mixed Fruits Juice', '2x1 l', '230', '10', '207', 'Juices and Drinks'),
('Butter.jpg', 'Peanut Butter', '500 gm', '250', '10', '225', 'Butter and Cheese'),
('Pedigree.jpg', 'Pedigree Chicken and Vegetable Dog Food', '10 Kg', '1790', '9', '1628.9', 'Dog Supplies'),
('Pomegranate.jpg', 'Pomegranate', '2 Unit', '95', '17', '78.85', 'Fruits'),
('potato.jpg', 'Potato', '1 Kg', '49', '24', '37.24', 'Vegetables'),
('Juice.jpg', 'Real Fruit Power Mixed Fruit Juice', '2x1 l', '220', '16', '184.8', 'Juices and Drinks'),
('Moisturiser.jpg', 'Skin Moisturiser', '400 ml', '360', '10', '324', 'Cosmetics'),
('Papdi.jpg', 'Soan Papdi', '500 gm', '159', '33', '106.53', 'Sweets'),
('Soda.jpg', 'Soda', '2 l', '60', '5', '57', 'Water and Soda'),
('Ketchup.jpg', 'Soumo Tomato Ketchup', '950 gm', '130', '43', '74.1', 'Sauces and Ketchups'),
('Sprite.jpg', 'Sprite Lime Flavored Soft Drink', '750 ml ', '45', '8', '41.4', 'Cold Drinks'),
('Shampoo.jpg', 'Sunsilk Shine Shampoo', '650 ml', '310', '5', '294.5', 'Hair Care'),
('Pepsi.jpg', 'Thumps Up', '1.75 l', '85', '8', '78.2', 'Cold Drinks'),
('Pickel.jpg', 'Top Mixed Pickles', '400 gm', '94', '23', '72.38', 'Pickles and Chutneys'),
('Poha.jpg', 'Vedaka Poha', '500 gm', '39', '0', '39', 'Rice and Other Grains'),
('Sauces.jpg', 'Veeba Mint Mayonnaise', '950 gm', '155', '36%', '99.2', 'Noodles and Suaces'),
('Baby_access.jpg', 'Viaggi Blue U Shape', '1 Unit', '2100', '42', '1218', 'Baby Accessories'),
('Cat_bed.jpg', 'Whiskas Cat Wet Food', '85 gm', '40', '10', '36', 'Cat Supplies'),
('Egg.jpg', 'White Healthy Daily Eggs Tray', '30 Units', '250', '8', '230', 'Bread and Eggs');
