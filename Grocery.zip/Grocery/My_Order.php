<?php
	ob_start();
	include("UserFirstHomePage.php");
	include("UserSecondHomePage.php");
?>
<?php
	include("connection.php");
	session_start();
	if(isset($_SESSION["UserName"]))
	{
		$user=$_SESSION["UserName"];
			$s="select * from payment where Email_id='".$user."'";
			$r=mysqli_query($conn,$s);
			$row=mysqli_fetch_assoc($r);
			$contact=$row["Contact_No"];
			$tprice=$row["Price"];
	}
?>
<html>
	<head>
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"
			rel="stylesheet" type="text/css">
		<script src="C:\bootstrap-4.4.1-dist\bootstrap-4.4.1-dist\js\bootstrap.min.js">
		</script>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,initial-scale=2">
		<style>
			#order{
				background:url("Images/5.jpg");
				background-size:cover;
			}
		</style>
	</head>
	<body id="order">
		<div class="container">
		<div>&nbsp;</div><div>&nbsp;</div>
			<div class="row">
				<div class="col-md-8">
					<h3><?php
							$p="select * from sign_up where Email_id='".$user."'";
							$o=mysqli_query($conn,$p);
							$i=mysqli_fetch_assoc($o);
							echo $i["Name"];
						?>
					</h3>
					<h4>Contact No. : <?php 
										echo $contact;
									?></h4>
					<div>&nbsp;</div><div>&nbsp;</div>
					<table border=1 cellpadding=8 width=90%>
						<tr  style='font-size:20px;'><th class="text-center">Product</th>
						<th class="text-center">Product Weight</th>
						<th class="text-center">Price</th>
						<th class="text-center">Date</th></tr>
						<?php
							$sql="select * from bought_product where Email_id='".$user."'";
							$res=mysqli_query($conn,$sql);
							if(isset($res))
							{
								while($data=mysqli_fetch_assoc($res))
								{
									$product=$data["Product_Type"];
									$weight=$data["Product_Weight"];
									$price=$data["Discount_Price"];
									$date=$data["Date"];
								echo "<tr align='center' style='font-size:18px;'>
										<td>$product</td>
										<td>$weight</td>
										<td>$price</td>
										<td>$date</td>
								</tr>";
								}
							}
						?>
					</table>
				</div>
			</div>
		</div>
	</body>
<html>