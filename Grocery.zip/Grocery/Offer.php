<?php
	include("connection.php");
	$sql="select * from add_offer";
	$res=mysqli_query($conn,$sql);
	if(isset($res))
	{
		echo "<div class='container' id='add_offer'>
			<div>&nbsp;</div>
			<div>&nbsp;</div>
			<div class='row'>";
		while($data=mysqli_fetch_assoc($res))
		{
			$pic=$data["Image"];
			$pt=$data["Product_Type"];
			$pw=$data["Product_Weight"];
			$pp=$data["Product_Price"];
			$o=$data["Offer"];
			$dp=$data["Discount_Price"];
			echo "<div class='col-md-4' id='offer'>
					<div class='text-center'><img src='Offer_Image/$pic' width=200 height=250></div>
					<div class='text-center'>
						<h2 class='bg-info' style='padding:10px'>$pt</h2>
						<h3>RS. $dp</h3>
						<h5><strike>RS. $pp</strike></h5>
						<h6 style='padding:5px;background:yellowgreen;color:white'>$o%OFF</h6>
					</div>
					<div>$pw</div><br>
					<div class='text-center'>
						<a href='add_to_my_chart.php?p=$pic&pt=$pt&dp=$dp&pp=$pp&o=$o&pw=$pw' 
						style='padding:10px;color:white;background:firebrick;'>Add to Chart to Buy</a>
					</div>
				</div>";
		}
		echo "</div></div>";
	}
?>
<html>
	<head>
		<style>
			#offer{
				border:1px solid black;
				padding:20px;
				margin-left:30px;
				max-width:350px;
				height:580px;
				margin-bottom:30px;
				border-radius:20px;
			}
			#offer a:hover{
				text-decoration:none;
				background:darkred;
			}
		</style>
	</head>
	<head>
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"
			rel="stylesheet" type="text/css">
		<script src="C:\bootstrap-4.4.1-dist\bootstrap-4.4.1-dist\js\bootstrap.min.js">
		</script>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,initial-scale=2">
	</head>
</html>