<?php
	include("connection.php");
	if(isset($_POST["add_category_btn"]))
	{
		$pic=$_FILES["image"]["name"];
		$name=$_POST["category_name"];
		$description=$_POST["category_description"];
		//echo $pic.",".$name.",".$description;
		move_uploaded_file($_FILES["image"]["tmp_name"],"Category_Image/".$pic);
		$sql="insert into add_category values('".$pic."','".$name."','".$description."')";
		$res=mysqli_query($conn,$sql);
		if($res!=0)
			$s=1;
		else
			$s=0;
		header("location:Add_Category.php?status=$s");
	}
?>