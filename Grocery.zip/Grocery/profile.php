<?php
	include("connection.php");
	if(isset($_REQUEST["e"]))
	{
		$email=$_REQUEST["e"];
		$sql="select * from sign_up where Email_Id='".$email."'";
		$res=mysqli_query($conn,$sql);
		if($res==1)
		{
			while($data=mysqli_fetch_assoc($res))
			{
			$name=$data["Name"];
			$contact=$data["Contact_No"];
			}
		}
		header("location:My_Profile.php?e=$email&n=$name&c=$contact");
	}
?>