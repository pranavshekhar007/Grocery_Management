<html>
	<head>
		<style>
			#admin_sec{
				background:turquoise;
				height:70px;
				color:black;
			}
			#admin_second a{
				color:black;
				font-size:22px;
				line-height:25px;
			}
			#admin_second a:hover{
				color:blue;
				font-size:25px;
				line-height:28px;
			}
		</style>
	</head>
	<head>
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"
			rel="stylesheet" type="text/css">
		<script src="C:\bootstrap-4.4.1-dist\bootstrap-4.4.1-dist\js\bootstrap.min.js">
		</script>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,initial-scale=2">
	</head>
	<body>
		<div class="container-fluid">
			<div class="row text-center" id="admin_sec"><div>&nbsp;</div>
				<nav>
					<div class="col-md-3" id="admin_second">
						<a href="AdminHomePage.php">Home</a>
					</div>
					<div class="col-md-3" id="admin_second">
						<a href="Admin_Category.php">Category</a>
					</div>
					<div class="col-md-3" id="admin_second">
						<a href="Admin_Offer.php">Offers</a>
					</div>
					<div class="col-md-3" id="admin_second">
						<a href="Admin_About_Product.php">About_Product</a>
					</div>
				</nav>
			</div>
		</div>
	</body>
</html>