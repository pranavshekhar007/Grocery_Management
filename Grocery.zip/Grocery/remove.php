<?php
	include("connection.php");
	if(isset($_REQUEST["pt"]))
	{
		$pt=$_REQUEST["pt"];
		$sql="delete from mychart where Product_Type='".$pt."'";
		$res=mysqli_query($conn,$sql);
		header("location:My_Chart.php");
	}
?>