<?php
	include("FirstHomePage.php");
	include("SecondHomePage.php");
?>
<?php
	include("connection.php");
	if(isset($_POST["rateus_btn"]))
	{
		$rate=$_POST["rate_us"];
		$email_id=$_POST["email_id"];
		$sql="insert into rate_us value('".$email_id."','".$rate."')";
		$res=mysqli_query($conn,$sql);
		if($res!=0)
			$s=1;
		else
			$s=0;
	}
?>
<html>
	<head>
		<style>
			.rate{
				border:none;
				font-size:20px;
				font-weight:bold;
			}
			#rate{
				background:url("Images/1.jpg");
				background-size:cover;
			}
		</style>
		<script>
			function call()
			{
				document.f.rate_us.value=document.f.rateus.value;
			}
		</script>
	</head>
	<head>
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"
		rel="stylesheet" type="text/css">
		<script src="C:\bootstrap-4.4.1-dist\bootstrap-4.4.1-dist\js\bootstrap.min.js">
		</script>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,initial-scale=2">
	</head>
	<body id="rate">
		<div class="container">
			<div class="row">
				<h2>RATE US HERE</h2><br>
			</div>
			<div class="row">
			<div class="col-md-7">
			<form name="f" action="<?php $_PHP_SELF ?>" method="post">
				<input type="email" name="email_id" class="form-control" placeholder="Enter Email Address">
				<div>&nbsp;</div>
				<?php
					if(isset($s))
					{
						if($s==1)
							echo "<div class='text-success'>Thanku for rating.. :)</div>";
						else if($s==0)
							echo "<div class='text-danger'>Unable to Rate now...Please try again.</div>";
					}
				?>
				<input type="text" readonly name="rate_us" class="rate">
				<div>&nbsp;</div>
				<b>0</b><input onchange="call()" type="range" name="rateus" min=0 max=5>
				<b>5</b>
				<div>&nbsp;</div>
				<input type="submit" value="RATE NOW" class="btn btn-primary btn-lg" name="rateus_btn">
			</form>
			</div>
			</div>
		</div><br><br>
	</body>
</html>
<?php
	include("FourthHomePage.php");
	include("FifthHomePage.php");
?>