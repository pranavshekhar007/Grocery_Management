<?php
	include("FirstHomePage.php");
	include("SecondHomePage.php");
?>
<html>
	<head>
		<style>
			#my_profile{
				background:url("Images/1.jpg");
				background-size:cover;
			}
			#prof{
				height:60px;
				padding-top:10px;
			}
			#profile{
				font-size:18px;
			}
		</style>
	</head>
	<head>
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"
		rel="stylesheet" type="text/css">
		<script src="C:\bootstrap-4.4.1-dist\bootstrap-4.4.1-dist\js\bootstrap.min.js">
		</script>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,initial-scale=2">
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js">
		</script>
		<script>
			function call(str)
			{
				var email=str;
				window.location="profile.php?e="+email;
			}
		</script>
	</head>
	<body  id="my_profile">
		<div class="container">
		<form name="f" action="Edit_Profile.php" method="post">
			<div>&nbsp;</div>	
			<div class="row">
				<div class="col-md-12">
					<h1 class="bg-primary text-center" id="prof">My Profile </h1>
				</div>
			</div>
			<div>&nbsp;</div>
					<?php
						$s=$_GET["status"];
						if(isset($s))
						{
							echo "<div class='row'>";
							if($s==1)
								echo "<div class='col-md-12 text-success' style='font-size:18px'>
								Edited Successfully</div>";
							else if($s==0)
								echo "<div class='col-md-12 text-danger' style='font-size:18px'>
								Sorry..Try again</div>";
							else if($s==2)
								echo "<div class='col-md-12 text-danger' style='font-size:18px'>
								Password and Confirm Password is not same</div>";
							else if($s==3)
								echo "<div class='col-md-12 text-danger' style='font-size:18px'>
								Password must be of 8 characters</div>";
							echo "</div>";
						}
					?>
			<div class="row">
				<div class="col-md-7">
					<p id="profile">Email_Id : </p>
					<span class="text-danger">* not changeable</span>
					<input type="email" name="email_id" readonly placeholder="Enter Email Id"
					class="form-control" onmouseout="call(this.value)" value="<?php
																				if(isset($_REQUEST["e"]))
																				{
																					echo $_REQUEST["e"];
																				}
																			?>">
				</div>
			</div>
			<div>&nbsp;</div>
			<div class="row">
				<div class="col-md-6">
					<p id="profile">Name : </p>
					<input type="text" name="name" id="name" class="form-control" value="<?php
																				if(isset($_REQUEST["n"]))
																				{
																					echo $_REQUEST["n"];
																				}
																			?>">
				</div>
			</div>
			<div>&nbsp;</div>
			<div class="row">
				<div class="col-md-6">
					<p id="profile">Contact No. : </p>
					<input type="text" name="contact_no" id="contact" class="form-control" value="<?php
																				if(isset($_REQUEST["c"]))
																				{
																					echo $_REQUEST["c"];
																				}
																			?>"> 
				</div>
			</div>
			<div>&nbsp;</div>
			<div class="row">
				<p id="profile" class="text-danger">&nbsp;&nbsp;
				(If you want to change password then enter it, otherwise leave it)*</p>
				<div class="col-md-6">
					<p id="profile">New Password : </p>
					<input type="Password" name="password" class="form-control" placeholder="Enter New Password">
				</div>
				<div class="col-md-6">
					<p id="profile">Confirm Password : </p>
					<input type="Password" name="confirm_password"class="form-control" placeholder="Enter Confirm Password">
				</div>
			</div>
			<div>&nbsp;</div>
			<div class="row">
				<div class="col-md-12">
					<input type="submit" value="Edit Profile" class="form-control btn btn-lg btn-primary">
				</div>
			</div>
		</form>
		<div>&nbsp;</div><div>&nbsp;</div>
		</div>
	</body>
</html>
<?php
	include("FourthHomePage.php");
	include("FifthHomePage.php");
?>