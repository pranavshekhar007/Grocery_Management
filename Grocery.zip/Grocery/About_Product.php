<html>
	<head>
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"
			rel="stylesheet" type="text/css">
		<script src="C:\bootstrap-4.4.1-dist\bootstrap-4.4.1-dist\js\bootstrap.min.js">
		</script>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,initial-scale=2">
	</head>
	<body>
		<div class="container">
			<div>&nbsp;</div><div>&nbsp;</div>
			<?php
				include("connection.php");
				$sql="select * from add_about_product";
				$res=mysqli_query($conn,$sql);
				if(isset($res))
				{
					while($data=mysqli_fetch_assoc($res))
					{
						$pic=$data["Pic"];
						$pt=$data["Product_Type"];
						$d=$data["Description"];
						echo "<div class='row' style='background:lightgray;padding:20px'>
									<div class='col-md-5'>
										<img src='Add_Detail_Image/$pic' width=200 height=150>
									</div>
									<div class='col-md-7'>
										<h2 class='text-success'>$pt</h2>
										<i style='font-size:20px;color:black'>$d</i>
									</div>
								</div>
								<div>&nbsp;</div><div>&nbsp;</div>";
					}
				}
			?>
		</div>
	</body>
</html>