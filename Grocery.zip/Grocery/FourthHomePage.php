<!doctype html>
<html>
	<head>
		<style>
			.e{
				background:black;
				height:185px;
				opacity:0.5;
				color:lightslategray;
				margin-bottom:0;
			}
			ul li:hover a{
				font-size:25px;
				color:green;
			}
			.four{
				color:lightslategray;
			}
			ul li{
				font-size:16px;
			}
		</style>
	</head>
	<head>
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"
			rel="stylesheet" type="text/css">
		<script src="C:\bootstrap-4.4.1-dist\bootstrap-4.4.1-dist\js\bootstrap.min.js">
		</script>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,initial-scale=2">
	</head>
	<body>
		<div class="container-fluid">
			<div class="row e text-center">
				<div class="col-md-4"><h2 class="four">Information</h2>
									<ul class="list-unstyled">
										<li><a href="About_Us.php">About us</a></li>
										<li><a href="FAQ.php">FAQs</a></li>
									</ul>
				</div>
				<div class="col-md-4"><h2 class="four">Meetus On</h2>
								<ul class="list-unstyled">
									<li>Facebook</li>
									<li>Instagram</li>
									<li>Hike</li>
									<li>Twitter</li>
									<li>You Tube</li>
								</ul>
				</div>
				<div class="col-md-4"><h2 class="four">Contact us</h2>
								<ul class="list-unstyled">
									<li>123/abc Kalayanpur, Kanpur</li>
									<li>Pincode-206743</li>
									<li>Contact no.-1234567890,</li>
									<li>0987654321</li>
								</ul>
				</div>
			</div>
		</div>
	</body>
</html>