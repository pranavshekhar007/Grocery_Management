<?php
	include("connection.php");
	$email=$_POST["email_id"];
	$name=$_POST["name"];
	$contact_no=$_POST["contact_no"];
	$password=$_POST["password"];
	$confirm_password=$_POST["confirm_password"];
	$pass=strlen("$password");
	if($password==$confirm_password)
	{
		if($pass>=8)
		{
			$sql="update sign_up set Name='".$name."',Password='".$password."',
			Contact_No='".$contact_no."' where Email_Id='".$email."'";
			$res=mysqli_query($conn,$sql);
			if($res!=0)
				$s=1;
			else
				$s=0;
		}
		else
			$s=3;
	}
	else
		$s=2;
	header("location:My_Profile.php?status=$s");
?>