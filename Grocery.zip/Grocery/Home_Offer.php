<?php
	include("FirstHomePage.php");
	include("SecondHomePage.php");
	include("Offer.php");
	include("FourthHomePage.php");
	include("FifthHomePage.php");
?>