<?php
	include("FirstHomePage.php");
	include("SecondHomePage.php");
?>
<?php
	include("connection.php");
	if(isset($_POST["feedback_btn"]))
	{
		$name=$_POST["name"];
		$email_id=$_POST["email_id"];
		$contact_no=$_POST["contact_no"];
		$comment_type=$_POST["comment_type"];
		$comment=$_POST["comment"];
		$sql="insert into Feedback values('".$name."','".$email_id."','".$contact_no."',
		'".$comment_type."','".$comment."')";
		$res=mysqli_query($conn,$sql);
		if($res!=0)
			$s=1;
		else
			$s=0;
	}
?>
<html>
	<head>
		<style>
			#feed{
				background:url("Images/9.jpg");
				background-size:cover;
			}
			.feed{
				border:2px solid black;
			}
			.feed1{
				font-size:18px;
			}
			.radio{
				margin-left:20px;
			}
		</style>
	</head>
	<head>
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"
			rel="stylesheet" type="text/css">
		<script src="C:\bootstrap-4.4.1-dist\bootstrap-4.4.1-dist\js\bootstrap.min.js">
		</script>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,initial-scale=2">
	</head>
	<body id="feed">
		<div>&nbsp;</div>
		<div>&nbsp;</div>
		<div class="container feed">
		<form name="f" action="<?php $_PHP_SELF ?>" method="post">
			<div>&nbsp;</div>
			<div class="row">
				<div class="col-md-12 text-center">
					<h1>FEEDBACK FORM </h1>
				</div>
			</div>
			<div>&nbsp;</div>
			<?php
				if(isset($s))
				{
					echo "<div class='row'>";
					if($s==1)
						echo "<div class='col-md-12 text-success'>Thanku For Giving Your Feedback.</div>";
					else
						echo "<div class='col-md-12 text-danger'>SORRY, unable to give Feedback.</div>";
				}
			?>
			<div>&nbsp;</div>
			<div class="row">
				<div class="col-md-3">&nbsp;
				</div>
				<div class="col-md-2">
					<label class="control-label feed1">Name</label>
				</div>
				<div class="col-md-5">
					<input type="text" name="name" required placeholder="Enter Name" class="form-control">
				</div>
			</div>
			<div>&nbsp;</div>
			<div class="row">
				<div class="col-md-3">&nbsp;
				</div>
				<div class="col-md-2">
					<label class="control-label feed1">Email_Id</label>
				</div>
				<div class="col-md-5">
					<input type="email" name="email_id" required placeholder="Enter Email_Id " 
					class="form-control">
				</div>
			</div>
			<div>&nbsp;</div>
			<div class="row">
				<div class="col-md-3">&nbsp;
				</div>
				<div class="col-md-2">
					<label class="control-label feed1">Contact No.</label>
				</div>
				<div class="col-md-5">
					<input type="text" name="contact_no" required placeholder="Enter Contact Number " 
					class="form-control">
				</div>
			</div>
			<div>&nbsp;</div>
			<div class="row">
				<div class="col-md-3">&nbsp;
				</div>
				<div class="col-md-2">
					<label class="control-label feed1">Comment Type</label>
				</div>
				<div class="col-md-5 form-group radio form-inline">
					<input type="radio" name="comment_type" value="Comments" class="feed2">Comments<br>
					<input type="radio" name="comment_type" value="Questions" class="feed2">Questions<br>
					<input type="radio" name="comment_type" value="Bug Reports" class="feed2">Bug Reports<br>
				</div>
			</div>
			<div>&nbsp;</div>
			<div class="row">
				<div class="col-md-3">&nbsp;
				</div>
				<div class="col-md-2">
					<label class="control-label feed1">Comment/Query</label>
				</div>
				<div class="col-md-5">
					<textarea cols=59 name="comment" class="form-control"></textarea>
				</div>
			</div>
			<div>&nbsp;</div>
			<div>&nbsp;</div>
			<div class="row">
				<div class="col-md-3">&nbsp;
				</div>
				<div class="col-md-7">
					<input type="submit" name="feedback_btn" value="SUBMIT" class="form-control btn
					btn-primary btn-lg">
				</div>
			</div>
			<div>&nbsp;</div>
			<div>&nbsp;</div>
		</form>
		</div>
	</body>
	<div>&nbsp;</div>
	<div>&nbsp;</div>
</html>
<?php
	include("FourthHomePage.php");
	include("FifthHomePage.php");
?>