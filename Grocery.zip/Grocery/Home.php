<?php
	include("FirstHomePage.php");
	include("SecondHomePage.php");
	include("ThirdHomePage.php");
	include("FourthHomePage.php");
	include("FifthHomePage.php");
?>