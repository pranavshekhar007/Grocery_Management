-- phpMyAdmin SQL Dump
-- version 2.9.2
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Jul 31, 2020 at 01:01 PM
-- Server version: 5.0.27
-- PHP Version: 5.2.1
-- 
-- Database: `mydb`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `sign_up`
-- 

CREATE TABLE `sign_up` (
  `Name` varchar(30) NOT NULL,
  `Email_Id` varchar(30) NOT NULL,
  `Password` varchar(15) NOT NULL,
  `Contact_No` int(10) NOT NULL,
  PRIMARY KEY  (`Email_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `sign_up`
-- 

INSERT INTO `sign_up` (`Name`, `Email_Id`, `Password`, `Contact_No`) VALUES 
('Admin', 'admin@gmail.com', 'admin123', 2147483647),
('Parmesh Kumar', 'p@gmail.com', 'kumar123', 987654321),
('Pragati Srivastava', 'ps@gmail.com', 'pragati123', 2147483647),
('Richa', 'r@gmail.com', 'richa123', 2147483647),
('Sushant Singh', 'ss@gmail.com', 'singh123', 2147483647);
