<?php
	ob_start();
	include("UserFirstHomePage.php");
	if(isset($_SESSION["UserName"]))
	{
		include("UserSecondHomePage.php");
		include("Category.php");
	}
	else
	{
		echo "<div>&nbsp;</div><div>&nbsp;</div>
			<div class='container'>
				<div class='row'>
					<div class='col-md-12'>
						<input type='text' value='For visiting the page, First You have to login'
							class='form-control text-center' readonly  id='error'>
					</div>
				</div>
			</div>";
	}
?>
<html>
	<head>
		<style>
			#error{
				border:2px solid red;
				color:red;
				font-size:20px;
				line-height:30px;
			}
		</style>
	</head>
</html>