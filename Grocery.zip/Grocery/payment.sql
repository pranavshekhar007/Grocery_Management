-- phpMyAdmin SQL Dump
-- version 2.9.2
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Jul 31, 2020 at 01:08 PM
-- Server version: 5.0.27
-- PHP Version: 5.2.1
-- 
-- Database: `mydb`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `payment`
-- 

CREATE TABLE `payment` (
  `Email_Id` varchar(30) NOT NULL,
  `Price` varchar(10) NOT NULL,
  `Contact_No` varchar(10) NOT NULL,
  `Address` varchar(60) NOT NULL,
  `Holder_Name` varchar(40) NOT NULL,
  `Bank_Name` varchar(60) NOT NULL,
  `Acc_No` varchar(20) NOT NULL,
  `Branch` varchar(30) NOT NULL,
  `Code` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `payment`
-- 

INSERT INTO `payment` (`Email_Id`, `Price`, `Contact_No`, `Address`, `Holder_Name`, `Bank_Name`, `Acc_No`, `Branch`, `Code`) VALUES 
('ss@gmail.com', '175.05', '8794561230', '121- A Block harsh nager lucknow(324267)', 'Sushant Singh', 'SBI', '743859734970', 'harsh nagar', 'sbin00098767'),
('ps@gmail.com', '41.4', '9889676347', '54/7 harsh nagar lucknow(374683)', 'Pragati Srivastava', 'SBI', '479856314568', 'harsh nagar', 'sbin00098767');
