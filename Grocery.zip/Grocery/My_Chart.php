<?php
	ob_start();
	include("UserFirstHomePage.php");
	include("UserSecondHomePage.php");
?><?php
	include("connection.php");
	session_start();			
	$user=$_SESSION["UserName"];
	$sql="select * from mychart where Email_Id='".$user."'";
	$res=mysqli_query($conn,$sql);
	if(isset($res))
	{
		echo "<div class='container'>
			<div>&nbsp;</div>
			<div>&nbsp;</div>
			<div class='row'>";
		while($data=mysqli_fetch_assoc($res))
		{
			$img=$data["Image"];
			$pt=$data["Product_Type"];
			$dp=$data["Discount_Price"];
			$pp=$data["Product_Price"];
			$o=$data["Offer"];
			$pw=$data["Product_Weight"];
			echo "<div class='col-md-4' id='chart'>
						<center>
						<img src='My_Chart_Image/$img' width=180 height=200>
						<h2 class='bg-info' style='padding:10px;'>$pt</h2>
						<h3>RS. $dp</h3>
						<h4><strike>RS. $pp</strike></h4>
						<h6 style='color:white;background:yellowgreen;padding:5px;'>$o%OFF</h6>
						<h5 class='text-left'>$pw</h5>
						<a href='buy.php?price=$dp&pt=$pt&pw=$pw' style='padding:10px;color:white;
						background:firebrick;'>&nbsp;BUY&nbsp;</a>
						<a href='remove.php?pt=$pt' style='background:firebrick;color:white;padding:10px'>
						&nbsp;REMOVE&nbsp;</a>
						</center>
				</div>";
		}
		echo "</div>";
		echo "<div>&nbsp;</div>
				<div>&nbsp;</div>";
		include("items.php");
	}
?>
<html>
	<head>
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"
			rel="stylesheet" type="text/css">
		<script src="C:\bootstrap-4.4.1-dist\bootstrap-4.4.1-dist\js\bootstrap.min.js">
		</script>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,initial-scale=2">
	</head>
	<head>
		<style>
			#chart{
				border:1px solid black;
				padding:20px;
				margin-left:30px;
				max-width:330px;
				margin-bottom:30px;
				border-radius:20px;
			}
			#chart a:hover{
				background:darkred;
				text-decoration:none;
			}
		</style>
	</head>
</html>