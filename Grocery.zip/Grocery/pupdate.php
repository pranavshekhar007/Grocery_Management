<?php
	include("connection.php");
	if(isset($_POST["update_product_btn"]))
	{
		$pic=$_FILES["img"]["name"];
		$pt=$_POST["product_type"];
		$cn=$_POST["category_name"];
		$o=$_POST["product_offer"];
		move_uploaded_file($_FILES["img"]["tmp_name"],"Product_Image/".$pic);
		$sql="update add_product set Category_Name='".$cn."',Offer='".$o."',Pic='".$pic."' 
		where Product_Type='".$pt."'";
		$res=mysqli_query($conn,$sql);
		if($res!=0)
			$s=3;
		else
			$s=4;
		header("location:Add_Product.php?status=$s");
	}
?>