<html>
	<head>
		<link href="C:\bootstrap-4.4.1-dist\bootstrap-4.4.1-dist\css\bootstrap.min.css"
			rel="stylesheet" type="text/css">
		<script src="C:\bootstrap-4.4.1-dist\bootstrap-4.4.1-dist\js\bootstrap.min.js">
		</script>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,initial-scale=2">
	</head>
	<body>
		<div class="container text-success bg-info">
			shubhi gupta
		</div>
	</body>
</html>