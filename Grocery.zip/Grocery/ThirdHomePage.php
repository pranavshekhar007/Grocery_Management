<!doctype html>
<html>
	<head>
		<style>
			.d{
				height:590px;
				background-size:cover;
			}
		</style>
	</head>
	<head>
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"
			rel="stylesheet" type="text/css">
		<script src="C:\bootstrap-4.4.1-dist\bootstrap-4.4.1-dist\js\bootstrap.min.js">
		</script>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,initial-scale=2">
	</head>
	<body>
		<div class="container-fluid">
			<div class="row d">
				<div class="col-md-12">
					<video width=100% height=590 controls autoplay>
						<source src="2.mp4" type="video/mp4">
					</video>
				</div>
			</div>
		</div>
	</body>
</html>