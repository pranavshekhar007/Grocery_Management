<?php
	include("connection.php");
	if(isset($_POST["add_product_btn"]))
	{
		$pn=$_POST["category_name"];
		$pt=$_POST["product_type"];
		$o=$_POST["product_offer"];
		$pic=$pic=$_FILES["img"]["name"];
		move_uploaded_file($_FILES["img"]["tmp_name"],"Product_Image/".$pic);
		$sql="insert into add_product values('".$pn."','".$pt."','".$o."','".$pic."')";
		$res=mysqli_query($conn,$sql);
		if($res!=0)
			$s=1;
		else
			$s=0;
		header("location:Add_Product.php?status=$s");
	}
?>