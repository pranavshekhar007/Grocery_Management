<?php
	include("AdminFirstHomePage.php");
	include("AdminSecondHomePage.php");
?>
<html>
	<head>
		<style>
			#cat{
				background:url("Images/5.jpg");
				background-size:cover;
			}
		</style>
	</head>
	<head>
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"
			rel="stylesheet" type="text/css">
		<script src="C:\bootstrap-4.4.1-dist\bootstrap-4.4.1-dist\js\bootstrap.min.js">
		</script>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,initial-scale=2">
	</head>
	<body id="cat">
		<div>&nbsp;</div>
		<div>&nbsp;</div>
		<div class="container">
			<div class="row">
				<h1>ADD CATEGORIES - </h1>
			</div>
			<div>&nbsp;</div>
			<?php
				if(isset($_GET["status"]))
				{
					$s=$_GET["status"];
					echo "<div class='row'>";
					if($s==1)
						echo "<div class='col-md-6 text-success' style='font-size:18px;'>
						Category Added Successfully</div>";
					else if($s==0)
						echo "<div class='col-md-6 text-danger' style='font-size:18px;'>
						Category is not added</div>";
					else if($s==3)
						echo "<div class='col-md-6 text-success' style='font-size:18px;'>
						Category is Updated</div>";
					else if($s==4)
						echo "<div class='col-md-6 text-danger' style='font-size:18px;'>
						Category is not Updated</div>";
					echo "</div>";
				}
			?>
			<div>&nbsp;</div>
			<form name="f" action="addcategory.php" method="post" enctype="multipart/form-data">
			<div class="row">
				<div class="col-md-6">
					<input type="file" name="image" class="form-control">
				</div>
			</div>
			<div>&nbsp;</div>
			<div class="row">
				<div class="col-md-6">
					<input type="text" name="category_name" placeholder="Enter Name of Category"
					class="form-control" required>
				</div>
			</div>
			<div>&nbsp;</div>
			<div class="row">
				<div class="col-md-6">
					<input type="text" name="category_description" placeholder="Enter Description for Category"
					class="form-control" required>
				</div>
			</div>
			<div>&nbsp;</div>
			<div class="row">
				<div class="col-md-6">
					<input type="submit" name="add_category_btn" value="Add Category"
					class="btn btn-primary btn-lg">
				</div>
			</div>
			<div>&nbsp;</div>
			</form>
			<div>&nbsp;</div><div>&nbsp;</div>
			<div class="row">
				<h2> Already Added Category - </h2>
			</div>
			<div>&nbsp;</div>
			<div class="row">
				<table border=1 style="border-collapse:collapse;width:60%" cellpadding=8>
				<thead align="center">
					<tr><th class="text-center">Pic</th>
						<th class="text-center">Category Name</th>
						<th class="text-center">Category Description</th>
						<th class="text-center">Delete</th>
						<th class="text-center">Edit</th>
					</tr>
				</thead>
				<tbody align="center">
					<?php	
						include("connection.php");
						$sql="select * from add_category";
						$res=mysqli_query($conn,$sql);
						if(isset($res))
						{
							while($data=mysqli_fetch_assoc($res))
							{	
								$p=$data["Category_pic"];
								$n=$data["Category_name"];
								$d=$data["Description"];
								echo "<tr>
										<td><img src='Category_Image/$p' width=150 height=100></td>
										<td>$n</td>
										<td>$d</td>
										<td><a href='delete_category.php?c=$n'>Delete</a></td>
										<td><a href='update_category.php?c=$n'>Edit</a></td>
									  </tr>";
							}
						}
					?>
				</tbody>
			</table>
		</div>
		<div>&nbsp;</div>
		<div>&nbsp;</div>
	</body>
</html>
