<?php
	include("FirstHomePage.php");
	include("SecondHomePage.php");
?><html>
	<head>
		<style>
			#sign_up{
				background:url("Images/3.jpg");
				background-size:cover;
			}
			#sign{
				border:1px solid black;
			}
			label{
				font-size:18px;
				margin-left:160px;
			}
			.result{
				font-size:22px;
				margin-left:160px;
			}
		</style>
		<script>
			function value_reset()
			{
				name=document.f.name.value;
				email_id=document.f.email_id.value;
				password=document.f.password.value;
				confirm_password=document.f.confirm_password.value;
				contact_no=document.f.contact_no.value;
				name=email_id=password=confirm_password=contact_no="";
			}
			function call()
			{
				document.f.password.type="text";
			}
			function out()
			{
				document.f.password.type="password";
			}
			function over()
			{
				document.f.confirm_password.type="text";
			}
			function nout()
			{
				document.f.confirm_password.type="password";
			}
		</script>
	</head>
	<head>
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"
			rel="stylesheet" type="text/css">
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js">
		</script>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,initial-scale=2">
	</head>
	<body id="sign_up">
		<div>&nbsp;</div>
		<div>&nbsp;</div>
		<div class="container" id="sign">
			<form action="Sign_Up.php" method="post" name="f">
				<div>&nbsp;</div>
				<div class="row">
					<div class="col-md-12 text-center">
						<h1>PLEASE SIGN UP</h1>
					</div>
				</div>
				<div>&nbsp;</div>
				<?php
					if(isset($_GET["s"]))
					{
						echo "<div class='row'>";
							$s=$_GET["s"];
							if($s==1)
								echo "<div class='col-md-12 text-success result'>
								Signed Up Successfully</div>";
							else if($s==0)
								echo "<div class='col-md-12 text-danger result'>
								Already Have An Account</div>";
							else if($s==2)
								echo "<div class='col-md-12 text-warning result'>
								Password and Confirm Password
								is not same</div>";
							else if($s==3)
								echo "<div class='col-md-12 text-warning result'>
								Password must be of 8 characters</div>";
						echo "</div>";
						echo "<div>&nbsp;</div>";
					}
				?>
				<div>&nbsp;</div>
				<div class="row">
					<div class="col-md-4">
							<label class="control-label">NAME</label>
					</div>
					<div class="col-md-6">
						<input type="text" name="name" placeholder="Enter Name" required class="form-control">
					</div>
				</div>
				<div>&nbsp;</div>
				<div class="row">
					<div class="col-md-4">
							<label class="control-label">EMAIL_ID</label>
					</div>
					<div class="col-md-6">
						<input type="email" name="email_id" placeholder="Enter Email_Id" required 
						class="form-control">
					</div>
				</div>
				<div>&nbsp;</div>
				<div class="row">
					<div class="col-md-4">
							<label class="control-label">PASSWORD</label>
					</div>
					<div class="col-md-6">
						<input type="password" name="password" placeholder="Enter Password" required 
						class="form-control">
					</div>
					<div class="col-md-1">
						<input type="image" src="Images/eye.png" width=30 height=30 onmouseover="call()"
						onmouseout="out()">
					</div>
				</div>
				<div>&nbsp;</div>
				<div class="row">
					<div class="col-md-4">
							<label class="control-label">CONFIRM PASSWORD</label>
					</div>
					<div class="col-md-6">
						<input type="password" name="confirm_password" placeholder="Enter Confirm Password"
						required class="form-control">
					</div>
					<div class="col-md-1">
						<input type="image" src="Images/eye.png" width=30 height=30 onmouseover="over()"
						onmouseout="nout()">
					</div>
				</div>
				<div>&nbsp;</div>
				<div class="row">
					<div class="col-md-4">
							<label class="control-label">CONTACT NO.</label>
					</div>
					<div class="col-md-6">
						<input type="text" name="contact_no" placeholder="Enter Contact Number"
						required class="form-control">
					</div>
				</div>
				<div>&nbsp;</div>
				<div>&nbsp;</div>
				<div class="row">
					<div class="col-md-6"><center>
							<input type="submit" value="SIGN UP" name="signup_btn" class="btn btn-primary
							btn-lg">
					</div>
					<div class="col-md-6">
							<input type="reset" value="RESET" name="reset_btn" class="btn btn-primary
							btn-lg" onclick="value_reset()">
					</div>
				</div>
				<div>&nbsp;</div>
				<div>&nbsp;</div>
			</form>
		</div>
	</body>
	<div>&nbsp;</div>
				<div>&nbsp;</div>
</html>
<?php
	include("FourthHomePage.php");
	include("FifthHomePage.php");
?>