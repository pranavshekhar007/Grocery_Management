-- phpMyAdmin SQL Dump
-- version 2.9.2
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Jul 31, 2020 at 01:06 PM
-- Server version: 5.0.27
-- PHP Version: 5.2.1
-- 
-- Database: `mydb`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `add_category`
-- 

CREATE TABLE `add_category` (
  `Category_pic` varchar(20) NOT NULL,
  `Category_name` varchar(30) NOT NULL,
  `Description` varchar(100) NOT NULL,
  PRIMARY KEY  (`Category_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `add_category`
-- 

INSERT INTO `add_category` (`Category_pic`, `Category_name`, `Description`) VALUES 
('12.webp', 'Baby Care', 'Baby Food, Diapers & wipes, Baby Skin & Hair Care, Baby Accessories.......'),
('6.webp', 'Beverages', 'Cold Drinks, Juices & Drinks, Tea & coffee, Health & Energy Drinks........'),
('7.webp', 'Breakfast and Dairy', 'Breakfast & dairy best Offers, Milk & Milk Products, Breads & Eggs, Paneer.......'),
('1.webp', 'Grocery and Staples', 'Pulses, Atta & other Flour, Rice & other grains, Dry Fruits & nuts......'),
('9.webp', 'Noodles and Sauces', 'Noodles & Sauces Best Offers, Noodles & Vermicelli, Sauces &...............'),
('3.webp', 'Personal Care', 'Safety Must Haves, Bath & Body, Hair Care, Skin Care.........'),
('11.webp', 'Pet Care', 'Dog Supplies, Cat Supplies'),
('5.webp', 'Snacks ', 'Chocolate & Candies, Biscuits & Cookies, Namkeen & Snacks, Chips.....'),
('2.webp', 'Vegetable and Fruits', 'Fruits like mango, orange... & vegetables like ladyfinger, potato..........');
