<?php
	include("connection.php");
	if(isset($_POST["add_offer_btn"]))
	{
		$pic=$_FILES["img"]["name"];
		$type=$_POST["product_type"];
		$w=$_POST["product_weight"];
		$p=$_POST["price"];
		$o=$_POST["offer"];
		$dp=$_POST["dis_price"];
		move_uploaded_file($_FILES["img"]["tmp_name"],"Offer_Image/".$pic);
		//echo $pic." ".$type." ".$w." ".$p." ".$w." ".$o;
		$sql="insert into add_offer values('".$pic."','".$type."','".$w."','".$p."','".$o."','".$dp."')";
		$res=mysqli_query($conn,$sql);
		if($res!=0)
			$s=1;
		else
			$s=0;
		header("location:Add_Offers.php?status=$s");
	}
?>