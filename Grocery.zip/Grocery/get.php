<?php
	include("connection.php");
	$id=$_POST["id"];
	$sql="select * from sign_up where Email_id='".$id."'";
	$res=mysqli_query($conn,$sql);
	$data=mysqli_fetch_assoc($res);
	if($res==1)
	{
		$value=array('status'=>'success','name'=>$data['Name'],'contact'=>'Contact_No');
	}
	else
	{
		$value=array('status'=>'failed');
	}
?>