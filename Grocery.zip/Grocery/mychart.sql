-- phpMyAdmin SQL Dump
-- version 2.9.2
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Jul 31, 2020 at 01:07 PM
-- Server version: 5.0.27
-- PHP Version: 5.2.1
-- 
-- Database: `mydb`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `mychart`
-- 

CREATE TABLE `mychart` (
  `Image` varchar(20) NOT NULL,
  `Product_Type` varchar(40) NOT NULL,
  `Discount_Price` varchar(10) NOT NULL,
  `Product_Price` varchar(10) NOT NULL,
  `Offer` varchar(10) NOT NULL,
  `Product_Weight` varchar(10) NOT NULL,
  `Email_Id` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `mychart`
-- 

INSERT INTO `mychart` (`Image`, `Product_Type`, `Discount_Price`, `Product_Price`, `Offer`, `Product_Weight`, `Email_Id`) VALUES 
('Tea.jpg', 'Lipton Darjeeling Tea', '437', '460', '5', '250 gm', 'ps@gmail.com'),
('Pampers.jpg', 'Pampers Premium Care Pants Diaper(L)', '807.73', '1049', '23', '44 unit', 'ps@gmail.com');
