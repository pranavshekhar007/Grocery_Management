<?php
	include("AdminFirstHomePage.php");
	include("AdminSecondHomePage.php");
	include("Offer.php");
?>