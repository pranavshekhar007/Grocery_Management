-- phpMyAdmin SQL Dump
-- version 2.9.2
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Jul 31, 2020 at 01:07 PM
-- Server version: 5.0.27
-- PHP Version: 5.2.1
-- 
-- Database: `mydb`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `feedback`
-- 

CREATE TABLE `feedback` (
  `Name` varchar(30) NOT NULL,
  `Email_Id` varchar(30) NOT NULL,
  `Contact_No` varchar(10) NOT NULL,
  `Comment_Type` varchar(15) NOT NULL,
  `Comment` varchar(100) NOT NULL,
  PRIMARY KEY  (`Email_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `feedback`
-- 

INSERT INTO `feedback` (`Name`, `Email_Id`, `Contact_No`, `Comment_Type`, `Comment`) VALUES 
('shubhi gupta', 's@gmail.com', '1234567890', 'Comments', 'Hi, this is too cool. I like the way of designing the pages.');
