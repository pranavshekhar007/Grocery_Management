<?php
	include("connection.php");
	if(isset($_POST["add_detail_btn"]))
	{
		$pic=$_FILES["img"]["name"];
		$type=$_POST["product_type"];
		$w=$_POST["description"];
		move_uploaded_file($_FILES["img"]["tmp_name"],"Add_Detail_Image/".$pic);
		//echo $pic." ".$type." ".$w." ".$p." ".$w." ".$o;
		$sql="insert into add_about_product values('".$pic."','".$type."','".$w."')";
		$res=mysqli_query($conn,$sql);
		if($res!=0)
			$s=1;
		else
			$s=0;
		header("location:Add_About_Product.php?status=$s");
	}
?>