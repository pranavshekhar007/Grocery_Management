<?php
	include("AdminFirstHomePage.php");
	include("AdminSecondHomePage.php");
?>
<html>	
	<head>
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"
			rel="stylesheet" type="text/css">
		<script src="C:\bootstrap-4.4.1-dist\bootstrap-4.4.1-dist\js\bootstrap.min.js">
		</script>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,initial-scale=2">
	</head>
	<body>
		<div class="container">
			<div>&nbsp;</div>
			<div>&nbsp;</div>
			<div class="row">
				<h1>Add About Product Details - </h1>
			</div>
			<div>&nbsp;</div>
			<?php
				if(isset($_GET["status"]))
				{
					$s=$_GET["status"];
					echo "<div class='row'>";
					if($s==1)
						echo "<div class='col-md-6 text-success' style='font-size:18px;'>
						Detail Added Successfully</div>";
					else if($s==0)
						echo "<div class='col-md-6 text-danger' style='font-size:18px;'>
						Detail is not added</div>";
					else if($s==3)
						echo "<div class='col-md-6 text-success' style='font-size:18px;'>
						Detail is updated</div>";
					else if($s==4)
						echo "<div class='col-md-6 text-danger' style='font-size:18px;'>
						Detail is not updated</div>";
					echo "</div>";
				}
			?>
			<div>&nbsp;</div>
			<form name="f" action="adddetail.php" method="post" enctype="multipart/form-data">
			<div class="row">
				<div class="col-md-6">
					<input type="file" name="img" class="form-control">
				</div>
			</div>
			<div>&nbsp;</div>
			<div class="row">
				<div class="col-md-6">
					<input type="text" name="product_type" placeholder="Enter Product Type Like:Atta, Rice.."
					required class="form-control">
				</div>
			</div>
			<div>&nbsp;</div>
			<div class="row">
				<div class="col-md-6">
					<textarea rows=4 class="form-control" placeholder="Enter Description" 
					name="description" required></textarea>
				</div>
			</div>
			<div>&nbsp;</div>
			<div class="row">
				<div class="col-md-6">
					<input type="submit" value="Add Details" class="btn btn-lg btn-primary" name="add_detail_btn">
				</div>
			</div>
			</form>
			<div>&nbsp;</div>
			<div>&nbsp;</div>
			<div>&nbsp;</div>
			<div class="row">
				<h2> Already Added About Product - </h2>
			</div>
			<div>&nbsp;</div>
			<div>&nbsp;</div>
			<div class="row">
				<div class="col-md-12">
					<table border=1 cellpadding=10>
						<tr>
							<th class="text-center">Pic</th>
							<th class="text-center">Product Type</th>
							<th class="text-center">Description</th>
							<th class="text-center">Delete</th>
							<th class="text-center">Edit</th>
						</tr>
							<?php
								include("connection.php");
								$sql="select * from add_about_product";
								$res=mysqli_query($conn,$sql);
								if(isset($res))
								{
									while($data=mysqli_fetch_assoc($res))
									{	
										$pic=$data["Pic"];
										$pt=$data["Product_Type"];
										$d=$data["Description"];
										echo "<tr align='center'>
											<td><img src='Add_Detail_Image/$pic' width=150 height=100></td>
											<td>$pt</td>
											<td>$d</td>
											<td><a href='delete_about_product.php?n=$pt'>Delete</a></td>
											<td><a href='update_about_product.php?q=$pt'>Edit</a></td>
											</tr>";
									}
								}
							?>
					</table>
					<div>&nbsp;</div><div>&nbsp;</div>
		</div>
	</body>
</html>