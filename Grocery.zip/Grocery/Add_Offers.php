<?php
	include("AdminFirstHomePage.php");
	include("AdminSecondHomePage.php");
?>
<html>
	<head>
		<style>
			#offer{
				background:url("Images/5.jpg");
				background-size:cover;
			}
		</style>
		<script>
			function call()
			{
				p=parseInt(document.f.price.value);
				d=parseInt(document.f.offer.value);
				d=p*(d/100);
				dis=p-d;
				document.f.dis_price.value=dis;
			}
		</script>
	</head>
	<head>
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"
			rel="stylesheet" type="text/css">
		<script src="C:\bootstrap-4.4.1-dist\bootstrap-4.4.1-dist\js\bootstrap.min.js">
		</script>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,initial-scale=2">
	</head>
	<body  id="offer">
		<div>&nbsp;</div>
		<div>&nbsp;</div>
		<div class="container">
			<div class="row">
				<h1>ADD OFFERS - </h1>
			</div>
			<div>&nbsp;</div>
			<?php
				if(isset($_GET["status"]))
				{
					$s=$_GET["status"];
					echo "<div class='row'>";
					if($s==1)
						echo "<div class='col-md-6 text-success' style='font-size:18px;'>
						Offer Added Successfully</div>";
					else if($s==0)
						echo "<div class='col-md-6 text-danger' style='font-size:18px;'>
						Offer is not added</div>";
					else if($s==3)
						echo "<div class='col-md-6 text-success' style='font-size:18px;'>
						Offer is updated</div>";
					else if($s==4)
						echo "<div class='col-md-6 text-danger' style='font-size:18px;'>
						Offer is not updated</div>";
					echo "</div>";
				}
			?>
			<div>&nbsp;</div>
			<form name="f" action="addoffer.php" method="post" enctype="multipart/form-data">
			<div class="row">
				<div class="col-md-6">
					<input type="file" name="img" class="form-control">
				</div>
			</div>
			<div>&nbsp;</div>
			<div class="row">
				<div class="col-md-6">
					<input type="text" name="product_type" placeholder="Enter Product Type Like:Atta, Rice.."
					required class="form-control">
				</div>
			</div>
			<div>&nbsp;</div>
			<div class="row">
				<div class="col-md-6">
					<input type="text" name="product_weight" placeholder="Enter Product Weight" required
					class="form-control">
				</div>
			</div>
			<div>&nbsp;</div>
			<div class="row">
				<div class="col-md-6">
					<input type="text" name="price" placeholder="Enter Price acc. to Weight" required
					class="form-control">
				</div>
			</div>
			<div>&nbsp;</div>
			<div class="row">
				<div class="col-md-6">
					<input type="text" name="offer" placeholder="Enter Offer in %" required
					class="form-control" onmouseout="call()">
				</div>
			</div>
			<div>&nbsp;</div>
			<div class="row">
				<div class="col-md-6">
					<input type="text" name="dis_price" placeholder="Price After Discount" class="form-control"
					readonly>
				</div>
			</div>
			<div>&nbsp;</div>
			<div class="row">
				<div class="col-md-6">
					<center><input type="submit" value="Add Offer" class="btn btn-primary btn-lg"
					name="add_offer_btn"></center>
				</div>
			</div>
			<div>&nbsp;</div>
			<div>&nbsp;</div>
			<div class="row">
				<h2> Already Added Offers - </h2>
			</div>
			<div>&nbsp;</div>
			<div>&nbsp;</div>
			<div class="row">
				<div class="col-md-12">
					<table cellpadding=10 border=1 width=90%>
						<tr>
							<th class="text-center">Pic</th>
							<th class="text-center">Product Type</th>
							<th class="text-center">Product Weight</th>
							<th class="text-center">Product Price</th>
							<th class="text-center">Offer</th>
							<th class="text-center">Discount Price</th>
							<th class="text-center">Delete</th>
							<th class="text-center">Edit</th>
						</tr>
							<?php
								include("connection.php");
								$sql="select * from add_offer";
								$res=mysqli_query($conn,$sql);
								if(isset($res))
								{
									while($data=mysqli_fetch_assoc($res))
									{	
										$pic=$data["Image"];
										$type=$data["Product_Type"];
										$weight=$data["Product_Weight"];
										$price=$data["Product_Price"];
										$off=$data["Offer"];
										$dp=$data["Discount_Price"];
										echo "<tr align='center'>
												<td><img src='Offer_Image/$pic' width=150 height=100></td>
												<td>$type</td>
												<td>$weight</td>
												<td>$price</td>
												<td>$off</td>
												<td>$dp</td>
												<td><a href='delete_offer.php?n=$type'>Delete</a></td>
												<td><a href='edit_offer.php?q=$type'>Edit</a></td>
											  </tr>";
									}
								}						
							?>
					</table>
				</div>
			</div>
		</div>
	</body>
</html>