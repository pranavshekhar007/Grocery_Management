<?php
	include("connection.php");
	if(isset($_POST["update_offer_btn"]))
	{
		$pic=$_FILES["img"]["name"];
		$pt=$_POST["product_type"];
		$pw=$_POST["product_weight"];
		$p=$_POST["price"];
		$o=$_POST["offer"];
		$dp=$_POST["dis_price"];
		move_uploaded_file($_FILES["img"]["tmp_name"],"Offer_Image/".$pic);
		$sql="update add_offer set Image='".$pic."',Product_Weight='".$pw."',Product_Price='".$p."',
		Offer='".$o."',Discount_Price='".$dp."' where Product_Type='".$pt."'";
		$res=mysqli_query($conn,$sql);
		if($res!=0)
			$s=3;
		else
			$s=4;
		header("location:Add_Offers.php?status=$s");
	}
?>