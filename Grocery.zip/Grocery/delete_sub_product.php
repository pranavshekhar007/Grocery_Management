<?php
	include("connection.php");
								if(isset($_REQUEST["n"]))
								{
									$t=$_REQUEST["n"];
									$sql="delete from add_sub_product where Product_Name='".$t."'";
									$res=mysqli_query($conn,$sql);
									if(isset($res))
									{
										header("location:Add_Sub_Product.php");					
									}
								}
?>