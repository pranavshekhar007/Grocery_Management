<html>
	<head>
		<style>
			#about{
				background:url("Images/back.jpg");
				height:200px;
				background-size:cover;
			}
			#para{
				font-size:18px;
				padding:40px;
			}
			#title{
				font-size:20px;
				font-weight:bold;
			}
			#about1{
				background:black;
				opacity:1.5;
			}
		</style>
	</head>
	<head>
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"
			rel="stylesheet" type="text/css">
		<script src="C:\bootstrap-4.4.1-dist\bootstrap-4.4.1-dist\js\bootstrap.min.js">
		</script>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,initial-scale=2">
	</head>
	<body>
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12" id="about">
					<div>&nbsp;</div><div>&nbsp;</div>
					<h1 style="margin-left:200px">Grocery
					<h3 style="margin-left:200px">The Super Market</h3></h1>
					<div class="text-right" style="font-size:20px;">
						<a href="Home.php" style="color:black">Home</a> > <i class="text-muted">About Us</i>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<h2 class="text-center">About Us</h2>
					<p align="justify" id="para">
						<i id="title">Grocery - The supermarket</i> is India's low price online supermarket in grocery space.
						The company uses its in-house technology plateform to manage a network of over 5,000
						parterns stores that enable the company to run a fast and lean supply chain - from 
						manufactures straight to customers in 27+ cities namely Agra, Ahemdabad, Aligarh, 
						Allahabad, Asansol, Benguluru, Bhiwadi, Chandigarh, Chennai, Delhi, Durgapur, Faridabad,
						Guhawati, Hapur, HR-NCR, Hyderabad, Indore, Jaipur, Kanpur, Kolkata, Luacknow, Meerut,
						Modinagar, Moradabad, Mumbai, Panipat, Pune, Rohtak, Sonipat, UP-NCR, Vadodara, and
						Zirakpur. <i id="title">Grocery - The supermarket</i> utilizes its efficient supply chain to deliver over
						25 million products to customers every months. A majority of these products belongs to
						the company house brand.
					</p>
					<p align="justify" id="para">
						<b>Online Grocery Shopping India</b><br>
						Shop on the go and buy groceries, fresh fruits & vegetables, cakes & other bakery
						items, and baby care product. We get it all delivered at your doorstep within hours.
						You not only save time but also money with our best prices and offers. We get Savings.
						<br><br><br>
						<b>Single App for all your daily Needs</b><br>
						Order thousands of product at just a tap; milk, egg, bread, cooking oil, ghee, atta, rice,
						fresh fuits & vegetables, spices, chocolates, chips, biscuits, Maggie, cold drinks, shampoos,
						soaps, baby wash, pet food, diapers, other oraganic and gournet products from your neighbourhood
						stores.
					</p>
				</div>
			</div>
		</div>
	</body>
</html>