<?php
    $conn=mysqli_connect("localhost","root","","grocery_DB");
    if(!$conn) // Corrected: !$conn instead of !conn
    {
        die("ERROR: could not connect to server");
    }
?>