-- phpMyAdmin SQL Dump
-- version 2.9.2
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Jul 31, 2020 at 01:04 PM
-- Server version: 5.0.27
-- PHP Version: 5.2.1
-- 
-- Database: `mydb`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `rate_us`
-- 

CREATE TABLE `rate_us` (
  `Email_Id` varchar(30) NOT NULL,
  `Star` varchar(5) NOT NULL,
  PRIMARY KEY  (`Email_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `rate_us`
-- 

INSERT INTO `rate_us` (`Email_Id`, `Star`) VALUES 
('r@gmail.com', '5'),
('s@gmail.com', '4');
