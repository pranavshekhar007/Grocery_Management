-- phpMyAdmin SQL Dump
-- version 2.9.2
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Jul 31, 2020 at 01:06 PM
-- Server version: 5.0.27
-- PHP Version: 5.2.1
-- 
-- Database: `mydb`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `add_offer`
-- 

CREATE TABLE `add_offer` (
  `Image` varchar(20) NOT NULL,
  `Product_Type` varchar(35) NOT NULL,
  `Product_Weight` varchar(20) NOT NULL,
  `Product_Price` varchar(10) NOT NULL,
  `Offer` varchar(50) NOT NULL,
  `Discount_Price` varchar(15) NOT NULL,
  PRIMARY KEY  (`Product_Type`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `add_offer`
-- 

INSERT INTO `add_offer` (`Image`, `Product_Type`, `Product_Weight`, `Product_Price`, `Offer`, `Discount_Price`) VALUES 
('all_out.webp', 'All Out Ultra', '6x45 ml', '390', '13', '339.3'),
('chakki_aata.webp', 'Chakki Atta', '10 Kg', '330', '21', '260.7'),
('harpic.webp', 'Harpic', '3x1 l', '504', '22', '393.12'),
('mustured_Oil.webp', 'Kacchi Dhani Mustard Oil', '1 l', '141', '24', '107.16'),
('oil.webp', 'Kacchi Dhani Oil', '1 litre', '181', '31', '124.89'),
('tide.webp', 'Tide Extra Power', '10 Kg + 3 Kg', '840', '8', '772.8'),
('vim.webp', 'Vim Gel', '750 ml', '155', '21', '122.45');
