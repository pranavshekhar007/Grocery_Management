<?php
	include("FirstHomePage.php");
	include("SecondHomePage.php");
	include("Product.php");
	include("FourthHomePage.php");
	include("FifthHomePage.php");
?>