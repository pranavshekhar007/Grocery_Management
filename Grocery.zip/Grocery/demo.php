<html>
	<head>
		<link href="C:\bootstrap-4.4.1-dist\bootstrap-4.4.1-dist\css\bootstrap.min.css"
			rel="stylesheet" type="text/css">
		<script src="C:\bootstrap-4.4.1-dist\bootstrap-4.4.1-dist\js\bootstrap.min.js">
		</script>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,initial-scale=2">
	</head>
	<body>
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<input type="text" class="form-control">
				</div>
			</div><br><br>
			<div class="row" style="background:#dcdcdc">
				<div class="col-md-6">
					<input type="button" class="btn btn-primary btn-lg" value="OK">
				</div>
				<div class="col-md-6">
					<h1 class="text-center">ict</h1>
				</div>
			</div>
		</div>
	</body>
</html>