-- phpMyAdmin SQL Dump
-- version 2.9.2
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Jul 31, 2020 at 01:07 PM
-- Server version: 5.0.27
-- PHP Version: 5.2.1
-- 
-- Database: `mydb`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `add_product`
-- 

CREATE TABLE `add_product` (
  `Category_Name` varchar(30) NOT NULL,
  `Product_Type` varchar(60) NOT NULL,
  `Offer` varchar(40) NOT NULL,
  `Pic` varchar(20) NOT NULL,
  PRIMARY KEY  (`Category_Name`,`Product_Type`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `add_product`
-- 

INSERT INTO `add_product` (`Category_Name`, `Product_Type`, `Offer`, `Pic`) VALUES 
('Baby Care', 'Baby Accessories', 'Up to 60% Off', 'bc3.webp'),
('Baby Care', 'Baby Food', 'Up to 15% Off', 'bc4.webp'),
('Baby Care', 'Baby Skin and Hair Care', 'Up To 44% Off', 'bc2.webp'),
('Baby Care', 'Diapers and Wipes', 'Up to 50% Off', 'bc1.webp'),
('Beverages', 'Cold Drinks', 'Up to 50% Off', 'bev2.webp'),
('Beverages', 'Health and Energy Drinks', 'Up To 41% Off', 'bev5.webp'),
('Beverages', 'Juices and Drinks', 'Up to 50% Off', 'bev3.webp'),
('Beverages', 'Tea and Coffee', 'Up to 50% Off', 'bev4.webp'),
('Beverages', 'Water and Soda', 'Up To 24% Off', 'bev6.webp'),
('Breakfast and Dairy', 'Bread and Eggs', 'Up To 45% Off', 'dairy1.webp'),
('Breakfast and Dairy', 'Butter and Cheese', 'Up to 15% Off', 'dairy5.webp'),
('Breakfast and Dairy', 'Paneer and Curd', 'Up To 30% Off', 'dairy4.webp'),
('Grocery and Staples', 'Atta and Other Flour', 'Up to 63% Off', 'staple2.webp'),
('Grocery and Staples', 'Pulses', 'Up to 51% Off', 'staple1.webp'),
('Grocery and Staples', 'Rice and Other Grains', 'Up to 58% Off', 'staple3.webp'),
('Grocery and Staples', 'Spices', 'Up to 54% Off', 'staple9.webp'),
('Noodles and Sauces', 'Noodles and Suaces', 'Up to 50% Off', 'noodle1.webp'),
('Noodles and Sauces', 'Pickles and Chutneys', 'Up to 50% Off', 'noodle7.webp'),
('Noodles and Sauces', 'Sauces and Ketchups', 'Up to 42% Off', 'noodle3.webp'),
('Personal Care', 'Cosmetics', 'Up To 30% Off', 'pc3.webp'),
('Personal Care', 'Hair Care', 'Up To 62% Off', 'pc2.webp'),
('Personal Care', 'Skin Care', 'Up To 63% Off', 'pc1.webp'),
('Pet Care', 'Cat Supplies', 'Up to 10% Off', 'pet2.webp'),
('Pet Care', 'Dog Supplies', 'Up to 64% Off', 'pet1.webp'),
('Snacks ', 'Chips and Crips', 'Up to 50% Off', 'snack4.webp'),
('Snacks ', 'Chocolate and Candies', 'Up to 20% Off', 'snack1.webp'),
('Snacks ', 'Sweets', 'Up to 50% Off', 'snack6.webp'),
('Vegetable and Fruits', 'Fruits', 'Up to 24% Off', 'veg2.webp'),
('Vegetable and Fruits', 'Vegetables', 'Up To 27% Off', 'veg1.webp');
