-- phpMyAdmin SQL Dump
-- version 2.9.2
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Jul 31, 2020 at 01:25 PM
-- Server version: 5.0.27
-- PHP Version: 5.2.1
-- 
-- Database: `mydb`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `add_about_product`
-- 

CREATE TABLE `add_about_product` (
  `Pic` varchar(20) NOT NULL,
  `Product_Type` varchar(40) NOT NULL,
  `Description` varchar(300) NOT NULL,
  PRIMARY KEY  (`Product_Type`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `add_about_product`
-- 

INSERT INTO `add_about_product` (`Pic`, `Product_Type`, `Description`) VALUES 
('Aata.jpg', 'Atta', 'it is manufactures in our own factory. it is fully safe and pure. we do not use any chemicals and all to make perfect we use pure raw material to manufacture aata.'),
('Baby_shampoo.jpg', 'Baby Shampoo', 'This shampoo is good for the babies hair..');
