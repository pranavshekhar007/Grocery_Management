<?php
	include("connection.php");
	$category_name=$_REQUEST["n"];
	if(isset($category_name))
	{
		$sql="select * from add_product where Category_Name='".$category_name."'";
		$res=mysqli_query($conn,$sql);
		if(isset($res))
		{
			echo "<div class='container'>
			<div>&nbsp;</div><div>&nbsp;</div><div class='row'>";
			while($data=mysqli_fetch_assoc($res))
			{
				$pic=$data["Pic"];
				$pt=$data["Product_Type"];
				$o=$data["Offer"];
				echo "<a href='Sub_Product.php?pt=$pt'>";
				echo "<div class='col-md-4' id='product'><center>
						<img src='Product_Image/$pic' width=250 height=200><hr width=70% color:gray size=2>
						<div style='font-size:20px;color:black;'>$pt</div>
						<b style='color:green;font-weight:normal;'>$o</b><br>
						</center>
					</div></a>";
			}
			echo "</div></div>";
		}
	}
?>
<html>
	<head>
		<style>
		#product{
			border:1px solid black;
			padding:20px;
			border-radius:20px;
			max-width:330px;
			margin-left:30px;
			margin-bottom:30px;
		}
		input[type="submit"]
		{
			display:none;
		}
		</style>
	</head>
	<head>
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"
			rel="stylesheet" type="text/css">
		<script src="C:\bootstrap-4.4.1-dist\bootstrap-4.4.1-dist\js\bootstrap.min.js">
		</script>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,initial-scale=2">
	</head>
</html>