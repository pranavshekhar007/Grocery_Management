<?php
	include("connection.php");
	if(isset($_REQUEST["n"]))
	{
		$t=$_REQUEST["n"];
		$sql="delete from add_about_product where Product_Type='".$t."'";
		$res=mysqli_query($conn,$sql);
		if(isset($res))
		{
			header("location:Add_About_Product.php");
		}
	}
?>