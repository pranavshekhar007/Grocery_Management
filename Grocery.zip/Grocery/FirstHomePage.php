<!doctype html>
<html>
	<head>
		<style>
			#first{
				background:darkturquoise;
				height:90px;
			}
			.b{
				font-size:20px;
				background:cadetblue;
				padding:10px;
				margin-left:100px;
			}
			i{
				margin-left:100px;
			}
			#first1 a{
				font-size:20px;
			}
			#first a:hover{
				font-size:23px;
			}
		</style>
		<script>
			function call(str)
			{
				var n=str;
				window.location="Search.php?p="+n;
			}
		</script>
	</head>
	<head>
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"
			rel="stylesheet" type="text/css">
		<script src="C:\bootstrap-4.4.1-dist\bootstrap-4.4.1-dist\js\bootstrap.min.js">
		</script>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,initial-scale=2">
		<script>
		</script>
		</head>
	<body>
		<div class="container-fluid">
			<div class="row" id="first">
				<div class="col-md-4">
					<div>&nbsp;</div>
					<b class="b">GRO-PRO</b><br>
					<i>Apki Apni Dukan...</i>
				</div>
				<div class="col-md-4"> 
					<div>&nbsp;</div>
						<?php
							include("connection.php");
							$sql="select * from add_sub_product";
							$res=mysqli_query($conn,$sql);
							if(isset($res))
							{
								echo "<input list='mylist' class='form-control' 
										placeholder='Product For Search' name='search' id='search'
										onmouseout='call(this.value)'><datalist id='mylist'>";
								while($row=mysqli_fetch_assoc($res))
								{
									echo "<option value='$row[Product_Name]'>";
								}
							}
						?>
				</div>
				<div class="col-md-4 text-center" id="first1"><br>
					<a href="My_Profile.php"><span class="glyphicon glyphicon-user"></span><a>
					<a href="sign.php" style="color:black">Sign Up </a>| 
					<a href="login.php" style="color:black"> Login</a>
				</div>
			</div>
		</div>
	</body>
</html>