<?php
	include("AdminFirstHomePage.php");
	include("AdminSecondHomePage.php");
	include("connection.php");
	$sql="select * from bought_product";
	$res=mysqli_query($conn,$sql);
	if(isset($res))
	{
		echo "<div class='container'>
				<div>&nbsp;</div><div>&nbsp;</div><div>&nbsp;</div>
				<div class='row'>
					<h1>Items Purchased - </h1>
				</div>
				<div>&nbsp;</div><div>&nbsp;</div>
				<div class='row'>
				<table border=1 cellpadding=10 width=80%>
				<tr>
					<th class='text-center'>Product</th>
					<th class='text-center'>Product Weight</th>
					<th class='text-center'>Price</th>
				</tr>";
				while($data=mysqli_fetch_assoc($res))
				{
					$pt=$data["Product_Type"];
					$pw=$data["Product_Weight"];
					$p=$data["Discount_Price"];
				}
				echo "<tr align='center'>
						<td>$pt</td>
						<td>$pw</td>
						<td>$p</td>
					</tr>";
			echo "</div></div>";	
	}
?>
<html>
	<head>
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"
			rel="stylesheet" type="text/css">
		<script src="C:\bootstrap-4.4.1-dist\bootstrap-4.4.1-dist\js\bootstrap.min.js">
		</script>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,initial-scale=2">
		<style>
			#view_item{
				background:url("Images/7.jpg");
				background-size:cover;
			}
		</style>
	</head>
	<body id="view_item">
	</body>
</html>