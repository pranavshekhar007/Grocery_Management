<?php
	include("connection.php");
	session_start();
	if(isset($_SESSION["UserName"]))
	{
		$user=$_SESSION["UserName"];
		$date=date("y-m-d");
		$sql="select * from bought_product where Email_Id='".$user."' and Date='".$date."'";
		$res=mysqli_query($conn,$sql);
		if(isset($res))
		{
			$tp=0;
			while($data=mysqli_fetch_assoc($res))
			{
					$dp=$data["Discount_Price"];
					$tp=$tp+$dp;
			}
			echo "<div style='background:black;color:white;padding:20px'>
						<form action='Payment.php?p=$tp' method='post'>
						<h3>Total Price : $tp</h3>
						<input type='submit' value='Purchase' class='btn btn-sm btn-primary'>
						</form>
					</div>";
		}
	}
?>
<html>
	<head>
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"
			rel="stylesheet" type="text/css">
		<script src="C:\bootstrap-4.4.1-dist\bootstrap-4.4.1-dist\js\bootstrap.min.js">
		</script>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,initial-scale=2">
	</head>
</html>