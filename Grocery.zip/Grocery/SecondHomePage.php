<!doctype html>
<html>
	<head>
		<style>
			#second{
				background:cyan;
				height:80px;
			}
			#sec{
				font-size:22px;
				color:black;
				line-height:26px;
				padding:15px;
			}
			#sec:hover{
				color:blue;
				font-size:25px;
				padding:20px;
				line-height:28px;
			}
		</style>
	</head>
	<head>
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"
			rel="stylesheet" type="text/css">
		<script src="C:\bootstrap-4.4.1-dist\bootstrap-4.4.1-dist\js\bootstrap.min.js">
		</script>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,initial-scale=2">
	</head>
	<body>
		<div class="container-fluid">
			<div class="row text-center" id="second">
				<div class="col-md-2"><br><a href="Home.php" style="font-size:25px;
												line-height:28px;padding:20px;
												text-decoration:underline;color:
												mediumblue;">Home</a></div>
				<div class="col-md-2"><br><a href="Main_Category.php" id="sec">Categories</a></div>
				<div class="col-md-2"><br><a href="Home_Offer.php" id="sec">Offers</a></div>
				<div class="col-md-2"><br><a href="Home_About_Product.php" id="sec">About_Product</a></div>
				<div class="col-md-2"><br><a href="feedback.php" id="sec">Feedback</a></div>
				<div class="col-md-2"><br><a href="Rate_us.php" id="sec">Rate_us</a></div>
			</div>
		</div>
	</body>
</html>