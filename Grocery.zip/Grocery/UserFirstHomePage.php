<?php
	ob_start();
?>
<html>
	<head>
		<style>
			#ad_first{
				background:darkturquoise;
				height:80px;
			}
			.admin_first{
				font-size:20px;
				background:cadetblue;
				padding:10px;
				margin-left:100px;
			}
			i{
				margin-left:100px;
			}
		</style>
		<script>
			function call(str)
			{
				var n=str;
				window.location="Search.php?p="+n;
			}
		</script>
	</head>
	<head>
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"
			rel="stylesheet" type="text/css">
		<script src="C:\bootstrap-4.4.1-dist\bootstrap-4.4.1-dist\js\bootstrap.min.js">
		</script>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,initial-scale=2">
	</head>
	<body>
		<div class="container-fluid">
			<div class="row" id="ad_first">
				<div class="col-md-4">
					<div>&nbsp;</div>
					<b class="admin_first">GRO-PRO</b><br>
					<i>Apki Apni Dukan...</i>
				</div>
				<div class="col-md-4"> 
					<div>&nbsp;</div>
						<?php
							include("connection.php");
							$sql="select * from add_sub_product";
							$res=mysqli_query($conn,$sql);
							if(isset($res))
							{
								echo "<input list='mylist' class='form-control' onmouseout='call(this.value)'
										placeholder='Product For Search' name='search'>
										<datalist id='mylist'>";
								while($row=mysqli_fetch_assoc($res))
								{
									echo "<option value='$row[Product_Name]'>";
								}
							}
						?>
				</div>
				<div class="col-md-4 text-center">
					<h3>Welcome <?php
									include("connection.php");
									session_start();
									if(isset($_SESSION["UserName"]))
									{
										$user=$_SESSION["UserName"];
										$sql="select * from sign_up where Email_Id='".$user."'";
										$res=mysqli_query($conn,$sql);
										$data=mysqli_fetch_assoc($res);
										echo $data["Name"];	
									}
								?> | <a href="Logout.php">LOGOUT</a></h3>
					
				</div>
			</div>
		</div>
</html>