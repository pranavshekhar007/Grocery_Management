<?php
	include("AdminFirstHomePage.php");
	include("AdminSecondHomePage.php");
	include("connection.php");
	echo "<div>&nbsp;</div><div>&nbsp;</div>";
	echo "<div class='container'>
			<div class='row'>
				<h1>Feedback - </h1>
			</div>";
	echo "<div>&nbsp;</div><div>&nbsp;</div>";
	$sql="select * from feedback";
	$res=mysqli_query($conn,$sql);
	if(isset($res))
	{
		echo "<table border=1 style='font-size:18px;' width=90%>
				<tr>
					<th class='text-center'>Name</th>
					<th class='text-center'>Email Id</th>
					<th class='text-center'>Contact No.</th>
					<th class='text-center'>Comment Type</th>
					<th class='text-center'>Comment</th>
				</tr>";
		while($data=mysqli_fetch_assoc($res))
		{
			$n=$data["Name"];
			$email=$data["Email_Id"];
			$contact=$data["Contact_No"];
			$ct=$data["Comment_Type"];
			$c=$data["Comment"];
			echo "<tr align='center'>
						<td>$n</td>
						<td>$email</td>
						<td>$contact</td>
						<td>$ct</td>
						<td>$c</td>
					</tr>";
		}
	}
	echo "</table></div>";
?>
<html>
	<head>
	</head>
	<head>
		<style>
			#view_feed{
				background:url("Images/1.jpg");
				background-size:cover;
			}
		</style>
	</head>
	<body id="view_feed">
	</body>
</html>