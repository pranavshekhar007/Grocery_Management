<html>
	<head>
		<style>
			#faq{
				background:url("Images/back.jpg");
				height:200px;
				background-size:cover;
			}
			#define{
				font-size:18px;
				padding:20px 30px 10px 30px;
			}
		</style>
	</head>
	<head>
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"
			rel="stylesheet" type="text/css">
		<script src="C:\bootstrap-4.4.1-dist\bootstrap-4.4.1-dist\js\bootstrap.min.js">
		</script>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,initial-scale=2">
	</head>
	<body>
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12" id="faq">
					<div>&nbsp;</div><div>&nbsp;</div>
					<h1 style="margin-left:200px">Grocery
					<h3 style="margin-left:200px">The Super Market</h3></h1>
					<div class="text-right" style="font-size:20px;">
						<a href="Home.php" style="color:black">Home</a> > <i class="text-muted">About Us</i>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<h2 class="text-center">General FAQ's</h2>
					<dl id="define">
						<dt>What is Grocery - The Super Market?</dt>
						<dd>
							Grocery - The Super Market is most convinient hyper local delivery company which enables
							you to order grocery, bakery, fruits & vegetables and other products that you need every
							day, directly via mobile or web browser.
						</dd>
					</dl>
					<dl id="define">
						<dt>What kind of products do you sell?</dt>
						<dd>
							You can choose from over 120,000 products spread across various categories such as grocery, bakery, fruits & vegetables, beverages, personal care products, baby care products, pet products and much more.
						</dd>
					</dl>
					<dl id="define">
						<dt>What cities and locations do you operate in?</dt>
						<dd>
							Grofers currently operates in Agra, Ahmedabad, Bengaluru, Bhubaneswar, Chennai, Cuttack, Chandigarh, Hyderabad, Indore, Jaipur, Kanpur, Kochi, Kolkata, Lucknow, Ludhiana, Madurai, Mumbai, NCR, Nagpur, Pune, Ranchi, Surat and Vadodara.

						</dd>
					</dl>
					<dl id="define">
						<dt>Do you deliver to my location?</dt>
						<dd>
							We deliver in select localities across the cities we are present in. You can edit your location settings to check if we deliver in your area.
						</dd>
					</dl>
					<dl id="define">
						<dt>What is the minimum order value?</dt>
						<dd>The minimum order value is INR800. However, each store has a minimum order value to qualify for free delivery as benchmark it should be INR1200. In case you do not reach the limit, a delivery charge will be levied against that order.
						</dd>
					</dl>
					<dl id="define">
						<dt>Do you charge any amount or taxes over and above the rates shown?</dt>
						<dd>No, we do not charge anything over and above the rates shown. However, we do have a delivery fee in case the order value per store does not reach the minimum order value for free delivery.
						</dd>
					</dl>
					<dl id="define">
						<dt>How can I make payments at Grofers?</dt>
						<dd>Grofers accepts multiple modes of payment. You can make online payments using credit cards, debit cards, netbanking, PayTM, PayU Money and Mobikwik Wallet. Cash on delivery (COD) is also available for orders less than Rs. 5000.

						</dd>
					</dl>
					<dl id="define">
						<dt>Is it safe to use my debit/credit card to shop on Grofers?</dt>
						<dd>Yes, it is. All transactions on Grofers are completed via secure payment gateways (Citrus, PayU) which are PCI and DSS compliant. We do not store your card details at any given time.
						</dd>
					</dl>
					<dl id="define">
						<dt>What are your delivery times?</dt>
						<dd>In some locations, our deliveries begin from 6 AM and the last delivery is completed by 11 PM.

						</dd>
					</dl>
				</div>
			</div>
		</div>
	</body>
</html>