<?php
	include("connection.php");
	session_start();
	if(isset($_SESSION["UserName"]))
	{
		$product_type=$_REQUEST["pt"];
		$discount_price=$_REQUEST["price"];
		$product_weight=$_REQUEST["pw"];
		$date=date("y-m-d");
		$sql="insert into bought_product values ('".$product_type."',
			'".$product_weight."','".$discount_price."','".$_SESSION['UserName']."','".$date."')";
		$res=mysqli_query($conn,$sql);
		header("location:My_Chart.php");
	}
?>