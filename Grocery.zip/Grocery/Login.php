<?php
	ob_start();
	include("FirstHomePage.php");
	include("SecondHomePage.php");
?>
<?php
	include("connection.php");
	$status=2;
	if(isset($_POST["login_btn"]))
	{	
		session_start();
		$email_id=$_POST["email_id"];
		$password=$_POST["password"];
		$_SESSION["UserName"]=$email_id;
		$sql="select * from sign_up where Email_Id='".$email_id."'";
		$res=mysqli_query($conn,$sql);
		$data=mysqli_fetch_assoc($res);
		if($_SESSION["UserName"]=="admin@gmail.com")
			header("location:AdminHomePage.php");
		else if($password==$data["Password"])
			header("location:UserHomePage.php");
		else 
			$status=0;
	}
?>
<html>
	<head>
		<style>
			#log{
				background:url("Images/5.jpg");
				background-size:cover;
			}
			.log{
				border:1px solid black;
			}
			.l{
				font-size:18px;
				margin-left:200px;
			}
		</style>
		<script>
			function value_reset()
			{
				e=document.f.email_id.value;
				p=document.f.password.value;
				e=p="";
			}
			function call()
			{
				document.f.password.type="text";
			}
			function out()
			{
				document.f.password.type="password";
			}
		</script>
	</head>
	<head>
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"
			rel="stylesheet" type="text/css">
		<script src="C:\bootstrap-4.4.1-dist\bootstrap-4.4.1-dist\js\bootstrap.min.js">
		</script>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,initial-scale=2">
	</head>
	<body id="log">
		<div>&nbsp;</div>
		<div>&nbsp;</div>
		<div class="container log">
			<form action="<?php $_PHP_SELF ?>" method="post" name="f">
				<div>&nbsp;</div>
				<center>
				<div class="row">
					<div class="col-md-12 text-center">
						<h1>PLEASE LOGIN</h1>
					</div>
				</div>
				<div>
					<?php
						$s = $_GET["status"];
						if($s == 0)
						{
							echo "<div class='text-danger'> incorrect password </div>";
						}
					?>
				</div>
				<div>&nbsp;</div>
				<div>&nbsp;</div>
				<div class="row">
					<div class="col-md-4">
							<label class="control-label l">EMAIL_ID</label>
					</div>
					<div class="col-md-5">
						<input type="email" name="email_id" placeholder="Enter Email_Id" required 
						class="form-control">
					</div>
				</div>
				<div>&nbsp;</div>
				<div class="row">
					<div class="col-md-4">
							<label class="control-label l">PASSWORD</label>
					</div>
					<div class="col-md-5">
						<input type="password" name="password" placeholder="Enter Password" required 
						class="form-control">
					</div>
					<div class="col-md-1">
						<input type="image" src="Images/eye.png" width=30 height=30 onmouseover="call()"
						onmouseout="out()">
					</div>
				</div>
				</center>
				<div>&nbsp;</div>
				<div>&nbsp;</div>
				<div class="row">
					<div class="col-md-6"><center>
							<input type="submit" value="LOGIN" name="login_btn" class="btn btn-primary
							btn-lg">
					</div>
					<div class="col-md-6">
							<input type="reset" value="RESET" name="reset_btn" class="btn btn-primary
							btn-lg text-left" onclick="value_reset()">
					</div>
				</div>
				<div>&nbsp;</div>
				<div class="row">
					<div class="col-md-12 text-center">
						<a href="Forget_Password.php">Forget Your Password?</a>
						<a href="sign.php">Create Account</a>
					</div>
				</div>
			</form>
			<div>&nbsp;</div><div>&nbsp;</div>
		</div>
	</body>
	<div>&nbsp;</div><div>&nbsp;</div>
<?php
	include("FourthHomePage.php");
	include("FifthHomePage.php");
?>