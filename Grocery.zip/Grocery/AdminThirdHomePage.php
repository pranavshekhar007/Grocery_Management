<html>
	<head>
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"
			rel="stylesheet" type="text/css">
		<script src="C:\bootstrap-4.4.1-dist\bootstrap-4.4.1-dist\js\bootstrap.min.js">
		</script>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,initial-scale=2">
	</head>
	<body>
		<div class="container-fluid"><center>
			<div>&nbsp;</div>
			<div>&nbsp;</div>
			<div>&nbsp;</div>
			<div>&nbsp;</div>
			<div>&nbsp;</div>
			<div>&nbsp;</div>
			<div class="row">
				<div class="col-md-3">
					<a href="Add_Category.php">
					<input type="image" src="Images/icon3.png" style="width:100px;height:100px"></a>
					<h4>Add Category </h4>
				</div>
				<div class="col-md-3">
					<a href="Add_Offers.php">
					<input type="image" src="Images/icon4.png" style="width:100px;height:100px"></a>
					<h4>Add Offers </h4>
				</div>
				<div class="col-md-3">
					<a href="Add_About_Product.php">
					<input type="image" src="Images/icon3.png" style="width:100px;height:100px"></a>
					<h4>Add About_Product Detail </h4>
				</div>
				<div class="col-md-3">
					<a href="Add_Product.php">
					<input type="image" src="Images/icon4.png" style="width:100px;height:100px"></a>
					<h4>Add Product	</h4>
				</div>
			</div>
			<div>&nbsp;</div>
			<div>&nbsp;</div>
			<div>&nbsp;</div>
			<div class="row">
				<div class="col-md-3">
					<a href="Add_Sub_Product.php">
					<input type="image" src="Images/icon4.png" style="width:100px;height:100px"></a>
					<h4>Add Sub_Product </h4>
				</div>
				<div class="col-md-3">
					<a href="View_Feedback.php">
					<input type="image" src="Images/icon.png" style="width:100px;height:100px"></a>
					<h4>View Feedback </h4>
				</div>
				<div class="col-md-3">
					<a href="View_Rate_Us.php">
					<input type="image" src="Images/icon1.png" style="width:100px;height:100px"></a>
					<h4>View Rates </h4>
				</div>
				<div class="col-md-3">
					<a href="View_Items.php">
					<input type="image" src="Images/icon.png" style="width:100px;height:100px"></a>
					<h4>View Item Purchsed </h4>
				</div>
			</div>
			<div>&nbsp;</div>
			<div>&nbsp;</div>
			<div>&nbsp;</div>
			</center>
		</div>
	</body>
</html>