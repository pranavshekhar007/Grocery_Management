<?php
	include("FirstHomePage.php");
	include("SecondHomePage.php");
	include("Category.php");
	include("FourthHomePage.php");
	include("FifthHomePage.php");
?>