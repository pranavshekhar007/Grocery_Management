<?php
	include("connection.php");
	session_start();
	if(isset($_SESSION["UserName"]))
	{
		$image=$_REQUEST["p"];
		$pro_type=$_REQUEST["pt"];
		$dis_price=$_REQUEST["dp"];
		$pro_price=$_REQUEST["pp"];
		$offer=$_REQUEST["o"];
		$pro_weight=$_REQUEST["pw"];
		if(isset($image))
		{
			copy("Offer_Image/$image","My_Chart_Image/$image");
		}
		//echo $image." ".$pro_type." ".$dis_price." ".$pro_price." ".$offer." ".$pro_weight;
		$sql="insert into mychart values('".$image."','".$pro_type."','".$dis_price."',
		'".$pro_price."','".$offer."','".$pro_weight."','".$_SESSION['UserName']."')";
		$res=mysqli_query($conn,$sql);	
			header("location:User_Offer.php");
	}
	else
		header("location:Home.php");
?>
