<!doctype html>
<html>
	<head>
		<style>
			.f{
				background:black;
				height:50px;
			}
			.fifth{
				line-height:30px;
				color:white;
				margin-top:5px;
			}
			a:hover{
				color:green;
				font-size:20px;
				text-decoration:none;
			}
		</style>
	</head>
	<head>
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"
			rel="stylesheet" type="text/css">
		<script src="C:\bootstrap-4.4.1-dist\bootstrap-4.4.1-dist\js\bootstrap.min.js">
		</script>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,initial-scale=2">
	</head>
	<body>
		<div class="container-fluid">
			<div class="row f">
				<div class="col-md-6 text-right fifth">
					<span class="glyphicon glyphicon-envelope"><a href="www.gmail.com" 
					style="color:white"> groceryd@gmail.com</a></span>
				</div>
				<div class="col-md-6 fifth">
					&copy;GroceryProduct@2020
				</div>
			</div>
		</div>
	</body>
</html>