<html>
	<head>
		<style>
			#category{
				background:white;
				height:180px;
			}
		</style>
	</head>
	<head>
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"
			rel="stylesheet" type="text/css">
		<script src="C:\bootstrap-4.4.1-dist\bootstrap-4.4.1-dist\js\bootstrap.min.js">
		</script>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,initial-scale=2">
	</head>
	<body>
		<div class="container-fluid">
				<?php
					include("connection.php");
					$sql="select * from add_category";
					$res=mysqli_query($conn,$sql);
					if(isset($res))
					{
						while($data=mysqli_fetch_assoc($res))
						{
							$p=$data["Category_pic"];
							$n=$data["Category_name"];
							$d=$data["Description"];
							echo "<center>";
							echo "<a href='Product.php?n=$n'";
							echo "<div class='row' id='category'>";
								echo "<div class='col-md-4'>
									<img src='Category_Image/$p' style='width:180px;height:150px;'>
								  </div>";
								echo "<div class='col-md-8'><h2 class='text-success'>$n</h2>
								<i style='font-size:20px;color:black'>$d</i>
								  </div>";
								echo "<div class='col-md-12' style='background:lightgray'>&nbsp;</div>";
							echo "</div></a></center>";
						}
					}
				?>
		</div>
	</body>
</html>
