<?php
	include("connection.php");
	if(isset($_POST["add_offer_btn"]))
	{
		$pic=$_FILES["img"]["name"];
		$category=$_POST["category_name"];
		$type=$_POST["product_type"];
		$w=$_POST["product_weight"];
		$p=$_POST["price"];
		$o=$_POST["offer"];
		$dp=$_POST["dis_price"];
		move_uploaded_file($_FILES["img"]["tmp_name"],"Sub_Product/".$pic);
		//echo $pic." ".$type." ".$w." ".$p." ".$w." ".$o;
		$sql="insert into add_sub_product values('".$pic."','".$type."','".$w."','".$p."','".$o."','".$dp."','".$category."')";
		$res=mysqli_query($conn,$sql);
		if($res!=0)
			$s=1;
		else
			$s=0;
		header("location:Add_Sub_Product.php?status=$s");
	}
?>