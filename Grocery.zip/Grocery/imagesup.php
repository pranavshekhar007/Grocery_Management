<?php
	$con=mysqli_connect("localhost","root","","ict");
	if(isset($_POST["btn"]))
	{
		echo $_FILE["img"]["name"];
		move_uploaded_file($_FILES["img"]["tmp_name"],"Images/".$name);
		$sql="insert into img value('".$name."')";
		$res=mysqli_query($con,$sql);
		if($res!=0)
			echo "inserted";
		else
			echo "sorry";
	}
?>
<html>
	<body>
	<form action="<?php $_PHP_SELF ?>" method="post" enctype="multipart/data-form">
		<input type="file" name="img">
		<input type="submit" name="btn">
	</form>
	</body>
</html>