-- phpMyAdmin SQL Dump
-- version 2.9.2
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Jul 31, 2020 at 01:07 PM
-- Server version: 5.0.27
-- PHP Version: 5.2.1
-- 
-- Database: `mydb`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `bought_product`
-- 

CREATE TABLE `bought_product` (
  `Product_Type` varchar(40) NOT NULL,
  `Product_Weight` varchar(10) NOT NULL,
  `Discount_Price` varchar(10) NOT NULL,
  `Email_Id` varchar(30) NOT NULL,
  `Date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `bought_product`
-- 

INSERT INTO `bought_product` (`Product_Type`, `Product_Weight`, `Discount_Price`, `Email_Id`, `Date`) VALUES 
('Coriander Powder', '200 gm', '50.16', 'ss@gmail.com', '2020-07-07'),
('Kacchi Dhani Oil', '1 litre', '124.89', 'ss@gmail.com', '2020-07-07'),
('Sprite Lime Flavored Soft Drink', '750 ml', '41.4', 'ps@gmail.com', '2020-07-09'),
('Johnson', '', '', 'ps@gmail.com', '2020-07-18');
