<?php
	ob_start();
	include("UserFirstHomePage.php");
	include("UserSecondHomePage.php");
?>
<html>
	<head>
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"
			rel="stylesheet" type="text/css">
		<script src="C:\bootstrap-4.4.1-dist\bootstrap-4.4.1-dist\js\bootstrap.min.js">
		</script>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,initial-scale=2">
		<style>
			#pay{
				background:url("Images/3.jpg");
				background-size:cover;
			}
		</style>
	</head>
	<body id="pay">
		<?php
			include("connection.php");
			session_start();
			if(isset($_SESSION["UserName"]))
			{
				$user=$_SESSION["UserName"];
				$total=$_REQUEST["p"];
			}
		?>
		<div class="container">
		<div>&nbsp;</div><div>&nbsp;</div>
		<form action="pay.php" method="post">
			<div class="row">
				<div class="col-md-6">
					<h4>Email Address :</h4>
					<input type="email" value="<?php echo $user; ?>" readonly name="email" class="form-control">
				</div>
			</div>
			<div>&nbsp;</div>
			<div class="row">
				<div class="col-md-6">
					<h4>Price to Pay :</h4>
					<input type="text" value="<?php echo $total; ?>" name="price" readonly class="form-control">
				</div>
			</div>
			<div>&nbsp;</div>
			<div class="row">
				<div class="col-md-6">
					<h4>Contact Number :</h4>
					<input type="text" name="contact_no" placeholder="Enter Contact Number" class="form-control">
				</div>
			</div>
			<div>&nbsp;</div>
			<div class="row">
				<div class="col-md-6">
					<h4>Address :</h4>
					<textarea name="address" placeholder="Enter Address" class="form-control"></textarea>
				</div>
			</div>
			<div>&nbsp;</div>
			<div> <a style=" width: 150px; background-color: #1065B7; text-align: center; font-weight: 800; padding: 11px 0px; color: #fff; font-size: 12px; display: inline-block; text-decoration: none; " href='https://pmny.in/BITOAeEawiZb' > Pay Now </a> </div>
		</form>
		</div>
	</body>
</html>