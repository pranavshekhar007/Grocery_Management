<?php
	include("connection.php");
	if(isset($_POST["update_category_btn"]))
	{
		$pic=$_FILES["image"]["name"];
		$name=$_POST["category_name"];
		$description=$_POST["category_description"];
		//echo $pic.",".$name.",".$description;
		move_uploaded_file($_FILES["image"]["tmp_name"],"Category_Image/".$pic);
		$sql="update add_category set Category_pic='".$pic."',
		Description='".$description."' where Category_name='".$name."'";
		$res=mysqli_query($conn,$sql);
		if($res!=0)
			$s=3;
		else
			$s=4;
		header("location:Add_Category.php?status=$s");
	}
?>