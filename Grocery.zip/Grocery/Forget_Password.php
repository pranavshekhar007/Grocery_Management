<?php
	include("connection.php");
	if(isset($_POST["forget_password_btn"]))
	{
		$email_id=$_POST["email_id"];
		$password=$_POST["new_password"];
		$confirm_password=$_POST["confirm_password"];
		if($password==$confirm_password)
		{
			$s="select * from sign_up where Email_Id='".$email_id."'";
			$res=mysqli_query($conn,$s);
			session_start();
			$data=mysqli_fetch_assoc($res);
			if($res!=0)
			{
				$sql="update sign_up set Password='".$password."' where Email_Id='".$email_id."'";
				$r=mysqli_query($conn,$sql);
				if($r==1)
				{
					$_SESSION["UserName"]=$email_id;
					header("location:UserHomePage.php");
				}
			}
			else
			{
				echo "You don't have an account..";
			}
		}
		else
		{
			echo "Password and Confirm Password is not same";
		}
	}
?>
<?php
	include("FirstHomePage.php");
	include("SecondHomePage.php");
?>
<html>
	<head>
		<style>
			.forget{
				border:3px solid black;
			}
		</style>
	</head>
	<head>
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"
			rel="stylesheet" type="text/css">
		<script src="C:\bootstrap-4.4.1-dist\bootstrap-4.4.1-dist\js\bootstrap.min.js">
		</script>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,initial-scale=2">
		<style>
			#forget{
				background:url("Images/4.jpg");
				background-size:cover;
				background-position:center;
			}
		</style>
	</head>
	<body id="forget">
		<div>&nbsp;</div>
		<div>&nbsp;</div>
		<div class="container forget">
			<form action="<?php $_PHP_SELF ?>" method="post" name="f"><center>
				<div>&nbsp;</div>
				<div>&nbsp;</div>
				<div>&nbsp;</div>
				<div class="row">
					<div class="col-md-12">
						<input type="email" name="email_id" placeholder="Enter Email_Id" required 
						class="form-control" style="width:500px">
					</div>
				</div>
				<div>&nbsp;</div>
				<div class="row">
					<div class="col-md-12">
						<input type="password" name="new_password" placeholder="Enter New Password" required 
						class="form-control" style="width:500px">
					</div>
				</div>
				<div>&nbsp;</div>
				<div class="row">
					<div class="col-md-12">
						<input type="password" name="confirm_password" placeholder="Enter Confirm Password" 
						required class="form-control" style="width:500px">
					</div>
				</div>
				<div>&nbsp;</div><div>&nbsp;</div>
				<div class="row">
					<div class="col-md-12">
						<input type="submit" name="forget_password_btn" value="SET" 
						class="btn btn-primary btn-lg" style="width:100px">
					</div>
				</div>
				<div>&nbsp;</div><div>&nbsp;</div>
			</form>
		</div>
		<div>&nbsp;</div><div>&nbsp;</div>
	</body>
</html>
<?php
			include("FourthHomePage.php");
			include("FifthHomePage.php");
	?>
