<?php
	include("AdminFirstHomePage.php");
	include("AdminSecondHomePage.php");
?>
<html>
	<head>
		<style>
			#pro{
				background:url("Images/5.jpg");
				background-size:cover;
			}
		</style>
	</head>
	<head>
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"
			rel="stylesheet" type="text/css">
		<script src="C:\bootstrap-4.4.1-dist\bootstrap-4.4.1-dist\js\bootstrap.min.js">
		</script>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,initial-scale=2">
	</head>
	<body id="pro">
		<div>&nbsp;</div>
		<div>&nbsp;</div>
		<div class="container">
			<form action="addproduct.php" method="post" enctype="multipart/form-data">
				<div class="row">
					<h2>Add Product - </h2>
				</div>
				<div>&nbsp;</div>
				<?php
				if(isset($_GET["status"]))
				{
					$s=$_GET["status"];
					echo "<div class='row'>";
					if($s==1)
						echo "<div class='col-md-6 text-success' style='font-size:18px;'>
						Product Added Successfully</div>";
					else if($s==0)
						echo "<div class='col-md-6 text-danger' style='font-size:18px;'>
						Product is not added</div>";
					else if($s==3)
						echo "<div class='col-md-6 text-success' style='font-size:18px;'>
						Product is updated</div>";
					else if($s==4)
						echo "<div class='col-md-6 text-danger' style='font-size:18px;'>
						Product is not updated</div>";
					echo "</div>";
				}
				?>
				<div>&nbsp;</div>
				<div class="row">
					<div class="col-md-6">
						<select name="category_name" class="form-control">
							<?php
								include("connection.php");
								$s="select * from add_category";
								$r=mysqli_query($conn,$s);
								if(isset($r))
								{
								while($row=mysqli_fetch_assoc($r))
								{
									$cn=$row["Category_name"];
									echo "<option value='$cn'>$cn</option>";
								}
								}
							?>
						</select>
					</div>
				</div>
				<div>&nbsp;</div>
				<div class="row">
					<div class="col-md-6">
						<input type="text" name="product_type" required class="form-control"
						placeholder="Enter Product Type">
					</div>
				</div>
				<div>&nbsp;</div>
				<div class="row">
					<div class="col-md-6">
						<input type="text" name="product_offer" required class="form-control"
						placeholder="Enter Offer">
					</div>
				</div>
				<div>&nbsp;</div>
				<div class="row">
					<div class="col-md-6">
						<input type="file" name="img" required class="form-control">
					</div>
				</div>
				<div>&nbsp;</div>
				<div class="row">
					<div class="col-md-6">
						<input type="submit" value="Add Product" class="btn btn-primary btn-lg"
						name="add_product_btn">
					</div>
				</div>
				<div>&nbsp;</div>
				<div>&nbsp;</div>
			</form>
			<div class="row">
				<h2> Alreay Added Product - </h2>
			</div>
			<div>&nbsp;</div>
			<div>&nbsp;</div>
			<div class="row">
				<table border=1 cellspacong=10 cellpadding=10 width=80%>
					<thead>
					<tr><th class="text-center">Category Name</th>
						<th class="text-center">Product Type</th>
						<th class="text-center">Offer</th>
						<th class="text-center">Pic </th>
						<th class="text-center">Delete</th>
						<th class="text-center">Edit</th>
					</tr>
				</thead>
				<tbody align="center">
					<?php	
						include("connection.php");
						$sql="select * from add_product";
						$res=mysqli_query($conn,$sql);
						if(isset($res))
						{
							while($data=mysqli_fetch_assoc($res))
							{	
								$pn=$data["Category_Name"];
								$pt=$data["Product_Type"];
								$o=$data["Offer"];
								$p=$data["Pic"];
								echo $data["pic"];
								echo "<tr>
										<td>$pn</td>
										<td>$pt</td>
										<td>$o</td>
										<td><img src='Product_Image/$p' width=150 height=100></td>
										<td><a href='delete_product.php?n=$pt'>Delete</a></td>
										<td><a href='update_product.php?w=$pt'>Edit</a></td>
									  </tr>";
							}
						}
					?>
				</tbody>
				</table>
				<div>&nbsp;</div>
				<div>&nbsp;</div>
			</div>
		</div>
	</body>
</html>