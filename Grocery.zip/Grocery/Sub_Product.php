<?php
	include("connection.php");
	if(isset($_REQUEST["pt"]))
	{
		$pt=$_REQUEST["pt"];
		$sql="select * from add_sub_product where Product_Type='".$pt."'";
		$res=mysqli_query($conn,$sql);
		if(isset($res))
		{
			echo "<div class='container'>
					<div>&nbsp;</div>
					<div>&nbsp;</div>
					<div class='row'>";
			while($row=mysqli_fetch_assoc($res))
			{
				$pic=$row["Image"];
				$pn=$row["Product_Name"];
				$pw=$row["Product_Weight"];
				$pp=$row["Product_Price"];
				$o=$row["Offer"];
				$dp=$row["Discount_Price"];
				echo "<div class='col-md-4' id='subpro'>
						<center><img src='Sub_Product/$pic' width=150 height=180>
								<h2 class='bg-info' style='padding:10px'>$pn</h2>
								<h3>RS. $dp </h3>
								<h4><strike>RS. $pp</strike></h4>
								<h6 style='padding:5px;background:yellowgreen;color:white;'>$o% OFF</h6>
								<h5 class='text-left'>$pw</h5>
								<a href='add_to_my_chart1.php?p=$pic&pt=$pn&dp=$dp&pp=$pp&o=$o&pw=$pw' 
						style='padding:10px;color:white;background:firebrick;'>Add to Chart to Buy</a>
						</center>
					</div>";
			}
			echo "</div></div>";
		}
	}
?>
<html>
	<head>
		<style>
			#subpro{
				border:1px solid black;
				padding:20px;
				margin-left:30px;
				max-width:350px;
				height:560px;
				margin-bottom:30px;
				border-radius:20px;
			}
			#subpro a:hover{
				text-decoration:none;
				background:darkred;
			}
		</style>
	</head>
	<head>
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"
			rel="stylesheet" type="text/css">
		<script src="C:\bootstrap-4.4.1-dist\bootstrap-4.4.1-dist\js\bootstrap.min.js">
		</script>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,initial-scale=2">
	</head>
</html>