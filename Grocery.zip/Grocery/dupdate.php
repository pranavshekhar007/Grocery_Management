<?php
	include("connection.php");
	if(isset($_POST["update_detail_btn"]))
	{
		$pic=$_FILES["img"]["name"];
		$pt=$_POST["product_type"];
		$d=$_POST["description"];
		move_uploaded_file($_FILES["img"]["tmp_name"],"Add_Detail_Image/".$pic);
		$sql="update add_about_product set Pic='".$pic."',Description='".$d."' where Product_Type='".$pt."'";
		$res=mysqli_query($conn,$sql);
		if($res!=0)
			$s=3;
		else
			$s=4;
		header("location:Add_About_Product.php?status=$s");
	}
?>